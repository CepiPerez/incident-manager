<?php

Class FormRequest extends Request
{
    public $route;


    /* public function __construct($req)
    {
        //dd($req->all());

        foreach ($req->all() as $key => $val)
            $this->$key = $val;

        //dd($this);

    } */

    
}