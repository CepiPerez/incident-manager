@extends('minimal')

@section('title', $title)
@section('code', $code)
@section('message', $message)
