<?php

//session_destroy();

# This might be only necessary for local development using Docker
date_default_timezone_set('America/Argentina/Buenos_Aires');

# Global variables
$routes = array();
$observers = array();
$version = '';
$debuginfo = array();

$preventLazyLoading = false;
$preventSilentlyDiscardingAttributes = false;
$preventAccessingMissingAttributes = false;


#ini_set('memory_limit', '256M');

ini_set('display_errors', true);
error_reporting(E_ALL + E_NOTICE);
#ini_set('display_errors', false);
#error_reporting(0);

/* if (version_compare(phpversion(), '8.0.0', '>='))
{
    ini_set('display_errors', false);
    error_reporting(0);
} */

define ('_DIR_', dirname(__FILE__));

$_class_list = array();
$_model_list = array();

# Load all classes
if (!file_exists(_DIR_.'/../../storage/framework/config/classes.php'))
{
    //echo "CREATING CLASSES<br>";
    $it = new RecursiveDirectoryIterator(_DIR_.'/../../app');
    foreach(new RecursiveIteratorIterator($it) as $file)
    {
        if (substr(basename($file), -4)=='.php' || substr(basename($file), -4)=='.PHP')
        {
            $_class_list[str_replace('.php', '', str_replace('.PHP', '', basename($file)))] = realpath($file);
            if (strpos(realpath($file), '/app/models/')>0)
                $_model_list[] = str_replace('.php', '', str_replace('.PHP', '', basename($file)));
        }
    }
    $it = new RecursiveDirectoryIterator(_DIR_.'/../../database');
    foreach(new RecursiveIteratorIterator($it) as $file)
    {
        if (substr(basename($file), -4)=='.php' || substr(basename($file), -4)=='.PHP')
        {
            $_class_list[str_replace('.php', '', str_replace('.PHP', '', basename($file)))] = realpath($file);
        }
    }

    $it = new RecursiveDirectoryIterator(_DIR_.'/../baradur');
    foreach(new RecursiveIteratorIterator($it) as $file)
    {
        if (substr(basename($file), -4)=='.php' || substr(basename($file), -4)=='.PHP')
        {
            $_class_list[str_replace('.php', '', str_replace('.PHP', '', basename($file)))] = realpath($file);
        }
    }

    $it = new RecursiveDirectoryIterator(_DIR_.'/../faker');
    foreach(new RecursiveIteratorIterator($it) as $file)
    {
        if (substr(basename($file), -4)=='.php' || substr(basename($file), -4)=='.PHP')
        {
            $_class_list[str_replace('.php', '', str_replace('.PHP', '', basename($file)))] = realpath($file);
        }
    }

    if (file_exists(_DIR_.'/../autoload.php'))
    {
        $real = _DIR_;
        $real = rtrim($real, 'baradur');
        $extra = include_once(_DIR_.'/../autoload.php');
        if (count($extra)>0)
        {
            foreach ($extra as $key => $val)
                $_class_list[$key] = $real.$val;
        }
    }

    @file_put_contents(_DIR_.'/../../storage/framework/config/classes.php', serialize($_class_list));
    @file_put_contents(_DIR_.'/../../storage/framework/config/models.php', serialize($_model_list));
}
else
{
    $_class_list = unserialize(file_get_contents(_DIR_.'/../../storage/framework/config/classes.php'));
    $_model_list = unserialize(file_get_contents(_DIR_.'/../../storage/framework/config/models.php'));
}

# Autoload function registration
spl_autoload_register('custom_autoloader');

# Environment variables
if (file_exists(_DIR_.'/../../storage/framework/config/env.php'))
{
    require_once(_DIR_.'/../../storage/framework/config/env.php');
}
else
{
    require_once('DotEnv.php');
    DotEnv::load(_DIR_.'/../../', '.env');
}


# Globals
require_once('Globals.php');

if (env('DEBUG_INFO')==1)
{
    global $debuginfo;
    $debuginfo['start'] = microtime(true);
}

# Global functions / Router functions
require_once('Global_functions.php');
require_once('Routing/Route_functions.php');


# Generating Application KEY (for Tokens usage)
require_once(_DIR_.'/../random_compat/lib/random.php');
if (!isset($_SESSION['key']))
    $_SESSION['key'] = bin2hex(random_bytes(32));


# MySQL Conector
$database = new Connector(env('DB_HOST'), env('DB_USER'), env('DB_PASSWORD'), env('DB_NAME'), env('DB_PORT'));

# Instantiating App
$app = new App();

# Instantiating Request
$app->singleton('request', 'Request');

# Including config file
$config = CoreLoader::loadConfigFile(_DIR_.'/../../config/app.php');

# Initializing locale
$locale = $config['locale'];
$fallback_locale = $config['fallback_locale'];

# Initializing App cache
$cache = new FileStore(new Filesystem(), _DIR_.'/../../storage/framework/cache/classes', 0777);

# Initializing Storage
Storage::$path = _DIR_.'/../../storage/app/public/';

# Loading Providers
$_service_providers = array();
foreach($config['providers'] as $provider)
{
    CoreLoader::loadClass(_DIR_.'/../../app/providers/'.$provider.'.php');
}
foreach ($_service_providers as $provider)
{
    $class = new $provider;
    $class->register();
    unset($class);
}
foreach ($_service_providers as $provider)
{
    $class = new $provider;
    $class->boot();
    unset($class);
}


# Autoload function
function custom_autoloader($class) 
{
    if (strpos($class, 'PHPExcel_')!==false) return;

    //echo "Loading Baradur class: ".$class."<br>";
 
    $newclass = '';

    global $_class_list;

    if (isset($_class_list[$class]))
        $newclass = $_class_list[$class];
    else
        return false;

    if (file_exists(_DIR_.'/../../storage/framework/cache/classes/'.$class.'.php'))
    {
        $date = filemtime($newclass);
        $cachedate = filemtime(_DIR_.'/../../storage/framework/cache/classes/'.$class.'.php');
        if ($date < $cachedate /* && env('APP_ENV')=='production' */)
        {
            if (file_exists(_DIR_.'/../../storage/framework/cache/classes/baradurClosures_'.$class.'.php'))
                require_once(_DIR_.'/../../storage/framework/cache/classes/baradurClosures_'.$class.'.php');

            require_once(_DIR_.'/../../storage/framework/cache/classes/'.$class.'.php');

            $newclass = '';
        } 
        else
        {
            @unlink(_DIR_.'/../../storage/framework/cache/classes/'.$class.'.php');
        }
    }
    
    if ($newclass!='') // && $version=='OLD')
    {
        $temp = file_get_contents($newclass);

        if (strpos($newclass, '/vendor/')==false)
        {
            if (strpos($temp, ' extends Model')>0 && strpos($temp, 'use SoftDeletes;')>0)
                $temp = str_replace('use SoftDeletes;', 'protected $useSoftDeletes = true;', $temp);

            $temp = replaceNewPHPFunctions($temp, $class, _DIR_);

            //echo "Saving class $class<br>";

            Cache::store('file')->setDirectory(_DIR_.'/storage/framework/cache/classes')
                ->plainPut(_DIR_.'/../../storage/framework/cache/classes/'.$class.'.php', $temp);
            $temp = null;
            
            require_once(_DIR_.'/../../storage/framework/cache/classes/'.$class.'.php');
        }
        else
        {
            require_once($newclass);
        }
    }
    
    
}

#dd("HOLA");

# Error handling
#set_exception_handler(array('ExceptionHandler', 'handleException'));
