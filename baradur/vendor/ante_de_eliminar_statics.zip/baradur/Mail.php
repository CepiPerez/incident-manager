<?php

Class Mail
{
    private static $_instance;
    protected $recipient;
    protected $cc = null;
    protected $bcc = null;
    protected $subject = '';

    
    /**
     * Get Route instance
     * 
     * @return Mail
     */
    public static function getInstance()
    {
        if (!self::$_instance)
            self::$_instance = new Mail();

        return self::$_instance;
    }


    /**
     * Set the email recipient
     * 
     * @return Mail
     */
    public static function to($recipient)
    {
        $res = self::getInstance();
        $res->recipient = $recipient;
        return $res;
    }

    /**
     * Add CC recipients
     * 
     * @return Mail
     */
    public static function cc($recipients)
    {
        $res = self::getInstance();
        $res->cc = $recipients;
        return $res;
    }

    /**
     * Add BCC recipients
     * 
     * @return Mail
     */
    public static function bcc($recipients)
    {
        $res = self::getInstance();
        $res->bcc = $recipients;
        return $res;
    }

    /**
     * Set the email subject
     * 
     * @return Mail
     */
    public static function subject($subject)
    {
        $res = self::getInstance();
        $res->subject = $subject;
        return $res;
    }

    public function send($template)
    {
        $final = $template->build(); 

        $vars = array();
        $view = $final->_template;
        unset($final->_template);

        foreach ($final as $key => $val)
        {
            $vars[$key] = $val;
        }

        $result = View::loadTemplate($view, $final);

        $default = config('mail.default');
        
        if ($default=='smtp')
            return $this->sendSmtp($result);

        if ($default=='sendmail')
            return $this->sendMail($result);


    }

    private function sendSmtp($content)
    {
        //echo "Sending through PHPMAILER<br>";
        require_once(_DIR_.'/../PHPMailer/PHPMailerAutoload.php');

        $default = config('mail.default');
        $mailers = config('mail.mailers'); 
        $from = config('mail.from'); 

        $mail = new PHPMailer();

        $mail->isSMTP();
        $mail->Host = $mailers[$default]['host'];
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = $mailers[$default]['encryption'];
        $mail->Username = $mailers[$default]['username'];
        $mail->Password = $mailers[$default]['password'];
        $mail->Port = $mailers[$default]['port'];

        $mail->setFrom($from['address'], $from['name']);
        $mail->addAddress($this->recipient);

        if (isset($this->cc))
        {
            if (is_array($this->cc))
            {
                foreach ($this->cc as $r)
                    $mail->addCC($r);
            }
            else
            {
                $mail->addCC($this->cc);
            }
        }

        if (isset($this->bcc))
        {
            if (is_array($this->bcc))
            {
                foreach ($this->bcc as $r)
                    $mail->addBCC($r);
            }
            else
            {
                $mail->addBCC($this->bcc);
            }
        }

        $mail->Subject = $this->subject;
        $mail->Body = $content;

        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;

        return $mail->send();

    }

    private function sendMail($content)
    {
        //echo "Sending through sendmail<br>";

        $from = config('mail.from'); 

        $encoding = "utf-8";
        $subject_preferences = array(
            "input-charset" => $encoding,
            "output-charset" => $encoding,
            "line-length" => 76,
            "line-break-chars" => "\r\n"
        );

        $header = "MIME-Version: 1.0 \r\n";
        $header .= "Content-type: text/html; charset=utf-8 \r\n";
        $header .= "Content-Transfer-Encoding: 8bit \r\n";
        $header .= "Date: ".date("r (T)")." \r\n";
        $header .= "From: ".$from['name']." <".$from['address']."> \r\n";
        $header .= 'To: '.$this->recipient."\r\n";
        $header .= iconv_mime_encode("Subject", $this->subject, $subject_preferences);
        
        return mail($this->recipient, $this->subject, $content, $header);

        //$this->xxmail('cepiperez@gmail.com', $this->subject, $content, $header);

    }


    /* private function xxmail($to, $subject, $body, $headers)
    {
        $smtp = stream_socket_client('tcp://smtp.mydomain.com:25', $eno, $estr, 30);

        $B = 8192;
        $c = "\r\n";
        $s = 'lisalalo';

        fwrite($smtp, 'helo ' . $_ENV['HOSTNAME'] . $c);
        $junk = fgets($smtp, $B);

        // Envelope
        fwrite($smtp, 'mail from: ' . $s . $c);
        $junk = fgets($smtp, $B);
        fwrite($smtp, 'rcpt to: ' . $to . $c);
        $junk = fgets($smtp, $B);
        fwrite($smtp, 'data' . $c);
        $junk = fgets($smtp, $B);

        // Header
        fwrite($smtp, 'To: ' . $to . $c);
        if(strlen($subject)) fwrite($smtp, 'Subject: ' . $subject . $c);
        if(strlen($headers)) fwrite($smtp, $headers); // Must be \r\n (delimited)
        fwrite($smtp, $headers . $c);

        // Body
        if(strlen($body)) fwrite($smtp, $body . $c);
        fwrite($smtp, $c . '.' . $c);
        $junk = fgets($smtp, $B);

        // Close
        fwrite($smtp, 'quit' . $c);
        $junk = fgets($smtp, $B);
        fclose($smtp);
    } */


}