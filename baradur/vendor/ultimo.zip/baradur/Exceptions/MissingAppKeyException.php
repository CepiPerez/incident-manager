<?php

class MissingAppKeyException extends RuntimeException
{
    //
}