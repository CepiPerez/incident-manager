<?php

class RouteNotFoundException extends InvalidArgumentException
{
    
}
