<?php

Class QueryBuilder
{
    public $_parent = null;
    public $_table;
    public $_primary;
    public $_foreign;
    public $_fillable;
    public $_guarded;
    public $_hidden;
    public $_routeKey;
    
    public $_fillableOff = false;

    public $_factory = null;

    public $_relationship;
    public $_rparent = null;

    public $_method = 'SELECT * FROM';
    public $_where = '';
    public $_wherevals = array();
    public $_join = '';
    public $_limit = null;
    public $_offset = null;
    public $_order = '';
    public $_group = '';
    public $_having = '';
    public $_union = '';
    public $_fromSub = '';
    public $_keys = array();
    public $_values = array();

    public $_eagerLoad = array();

    public $_collection = array();
    public $_connector;
    public $_extraquery = null;
    public $_original = null;

    public $_softDelete;
    public $_withTrashed = false;

    public $_relationVars = null;
    public $_loadedRelations = array();

    public function __construct($connector, $table, $primary, $parent, $fillable, $guarded, $hidden, $routeKey='id', $soft=false)
    {

        $this->_connector = $connector;
        $this->_table = $table;
        $this->_primary = is_array($primary)? $primary : array($primary);
        $this->_parent = $parent;
        $this->_fillable = $fillable;
        $this->_guarded = $guarded;
        $this->_hidden = $hidden;
        $this->_routeKey = $routeKey;
        $this->_softDelete = $soft? 1 : 0;
        $this->_collection = new Collection($parent, $hidden);

    }

    public function __call($method, $parameters)
    {
        if (method_exists($this->_parent, 'scope'.lcfirst($method)))
        {
            return Model::instance($this->_parent)->callScope(lcfirst($method), $parameters); 
        }

        if (! Str::startsWith($method, 'where')) {
            throw new Exception("Method $method does not exist");
        }

        return $this->where(Str::snake(substr($method, 5)), $parameters[0], $parameters[1]?$parameters[1]:null);
    }

    public function clear()
    {
        $this->_method = 'SELECT * FROM';
        $this->_where = '';
        $this->_join = '';
        $this->_limit = null;
        $this->_offset = null;
        $this->_group = '';
        $this->_union = '';
        $this->_having = '';
        $this->_order = '';
        $this->_fromSub = '';
        $this->_keys = array();
        $this->_values = array();
        $this->_wherevals = array();
    }

    private function arrayToObject($array)
    {
        if (count($array)==0)
            return array();

        $obj = new stdClass;
        foreach ($array as $key => $value)
        {
            if (is_array($value))
            {
                $obj->$key = $this->arrayToObject($value);
            } 
            else
            {
                $obj->$key = $value; 
            }
        }
        return $obj;
    }


    private function buildQuery()
    {
        if (strpos($this->_join, '!WHERE!')>0)
        {
            $this->_join = str_replace('!WHERE!', $this->_where, $this->_join);
            $this->_where = '';
        }

        $res = $this->_method;
        if ($this->_fromSub!='') $res .= $this->_fromSub . ' ';
        else $res .= ' `' . $this->_table . '` ';
        if ($this->_join != '') $res .= $this->_join . ' ';
        if ($this->_where != '') $res .= $this->_where . ' ';
        if ($this->_union != '') $res .= $this->_union . ' ';
        if ($this->_group != '') $res .= $this->_group . ' ';
        if ($this->_having != '') $res .= $this->_having . ' ';
        if ($this->_order != '') $res .= $this->_order . ' ';
        if (!$this->_limit && $this->_offset) $this->_limit = 9999999;
        if ($this->_limit) $res .= ' LIMIT '.$this->_limit;
        if ($this->_offset) $res .= ' OFFSET '.$this->_offset;

        return $res;
    }

    private function checkObserver($function, $model)
    {
        global $observers;
        $class = $this->_parent;
        if (isset($observers[$class]))
        {
            $observer = new $observers[$class];
            if (method_exists($observer, $function))
            {
                if (is_array($model))
                    $model = $this->insertUnique($model); 

                $observer->$function($model);
            }
        }
    }


    
    /**
     * Returns the full query in a string
     * 
     * @return string
     */
    public function toSql()
    {
        $res = $this->buildQuery();

        foreach ($this->_wherevals as $val)
        {
            foreach ($val as $k => $v)
                $res = preg_replace('/\?/', $v, $res, 1);
        }

        return $res;
    }



    /**
     * Specifies the SELECT clause\
     * Returns the Query builder
     * 
     * @param string $columns String containing colums divided by comma
     * @return QueryBuilder
     */
    public function selectRaw($val = '*')
    {
        $this->_method = 'SELECT ' . $val . ' FROM';
        return $this;
    }

    /**
     * Specifies the SELECT clause\
     * Returns the Query builder
     * 
     * @param string $columns String containing colums divided by comma
     * @return QueryBuilder
     */
    public function select($val)
    {
        if (!is_array($val)) $val = func_get_args();

        //dd($val); exit();

        $columns = array();
        foreach($val as $column)
        {
            list($col, $as, $alias) = explode(' ', $column);
            list($db, $col) = explode('.', $col);

            $col = trim($col);
            $as = trim($as); 
            $alias = trim($alias); 
            $db = trim($db);

            $columns[] = ($db=='*'? '*' : '`'.$db.'`') . 
                         ($col? '.' . ($col=='*'? '*' : '`'.$col.'`') : '') . 
                        (trim(strtolower($as))=='as'? ' as `'.$alias.'`':'');
        }

        $this->_method = 'SELECT ' . implode(', ', $columns) . ' FROM';
        return $this;
    }

    /**
     * Adds columns to the SELECT clause\
     * Returns the Query builder
     * 
     * @param string $columns String containing colums divided by comma
     * @return QueryBuilder
     */
    public function addSelect($val = '*')
    {
        $this->_method = rtrim($this->_method, ' FROM');
        $this->_method .= ', ' . $val . ' FROM';
        return $this;
    }

    /**
     * Specifies custom from\
     * Returns the Query builder
     * 
     * @param QueryBuilder $subquery
     * @param string $alias
     * @return QueryBuilder
     */
    public function fromSub($subquery, $alias)
    {
        $this->_fromSub = ' (' . $subquery->toSql() . ') ' . $alias;
        return $this;
    }


    /**
     * Specifies the WHERE clause\
     * Returns the Query builder
     * 
     * @param string $where
     * @return QueryBuilder
     */
    public function whereRaw($where)
    {
        if ($this->_where == '')
            $this->_where = 'WHERE ' . $where ;
        else
            $this->_where .= ' AND ' . $where;

        return $this;
    }

    /**
     * Specifies the WHERE clause\
     * Returns the Query builder
     * 
     * @param string $column 
     * @param string $condition Can be ommited for '='
     * @param string $value
     * @return QueryBuilder
     */
    public function where($column, $cond='', $val='', $ret=true)
    {
        if (is_array($column))
        {
            foreach ($column as $co)
            {
                //var_dump($co); echo "<br>";
                list($var1, $var2, $var3) = $co;
                $this->where($var1, $var2, $var3, false);
            }
            return $this;
        }


        if ($val=='')
        {
            $val = $cond;
            $cond = '=';
        }

        list ($table, $col) = explode('.', $column);
        if ($col) $column = '`'.$table.'`.`'.$col.'`';
        else $column = '`'.$this->_table.'`.`'.$table.'`';

        /* $vtype = 'i';
        if (is_string($val))
        {
            $vtype = 's';   
        }

        $this->_wherevals[] = array($vtype => $val); */

        if (is_string($val))
        {
            $val = rtrim(ltrim($val, "'"), "'");
            $val = "'$val'";
        }

        if ($this->_where == '')
            $this->_where = 'WHERE ' . $column . ' ' . $cond . ' ' . $val; // ' ?';
        else
            $this->_where .= ' AND ' . $column . ' ' .$cond . ' ' . $val; // ' ?';

        if ($ret) return $this;
    }

    /**
     * Specifies OR in WHERE clause\
     * Returns the Query builder
     * 
     * @param string $column 
     * @param string $condition Can be ommited for '='
     * @param string $value
     * @return QueryBuilder
     */
    public function orWhere($column, $cond, $val='', $ret=true)
    {
        if (is_array($column))
        {
            foreach ($column as $co)
            {
                //var_dump($co); echo "<br>";
                list($var1, $var2, $var3) = $co;
                $this->orWhere($var1, $var2, $var3, false);
            }
            return $this;
        }

        if ($val=='')
        {
            $val = $cond;
            $cond = '=';
        }

        list ($table, $col) = explode('.', $column);
        if ($col) $column = '`'.$table.'`.`'.$col.'`';
        else $column = '`'.$this->_table.'`.`'.$table.'`';

        /* $vtype = 'i';
        if (is_string($val))
        {
            $vtype = 's';   
        }

        $this->_wherevals[] = array($vtype => $val); */
        if (is_string($val)) $val = "'$val'";

        if ($this->_where == '')
            $this->_where = 'WHERE ' . $column . ' ' . $cond . ' ' . $val; // ' ?';
        else
            $this->_where .= ' OR ' . $column . ' ' .$cond . ' ' . $val; // ' ?';

        if ($ret) return $this;
    }

    /**
     * Specifies the WHERE IN clause\
     * Returns the Query builder
     * 
     * @param string $column 
     * @param string $values
     * @return QueryBuilder
     */
    public function whereIn($column, $values)
    {
        $win = array();
        if (!is_array($values))
        {
            foreach (explode(',', $values) as $val)
            {
                //$val = trim($val);
                if (is_string($val)) $val = "'".$val."'";
                array_push($win, $val);
            }
        }
        else
        {
            foreach ($values as $val)
            {
                if (is_string($val)) $val = "'".$val."'";
                array_push($win, $val);
            }
        }

        list ($table, $col) = explode('.', $column);
        if ($col) $column = '`'.$table.'`.`'.$col.'`';
        else $column = '`'.$table.'`';

        if ($this->_where == '')
            $this->_where = 'WHERE ' . $column . ' IN ('. implode(',', $win) .')';
        else
            $this->_where .= ' AND ' . $column . ' IN ('. implode(',', $win) .')';

        return $this;
    }

    /**
     * Specifies the WHERE IN clause\
     * Returns the Query builder
     * 
     * @param string $column 
     * @param string $values
     * @return QueryBuilder
     */
    public function orWhereIn($column, $values)
    {
        $win = array();
        if (!is_array($values))
        {
            foreach (explode(',', $values) as $val)
            {
                //$val = trim($val);
                if (is_string($val)) $val = "'".$val."'";
                array_push($win, $val);
            }
        }
        else
        {
            $win = $values;
        }

        list ($table, $col) = explode('.', $column);
        if ($col) $column = '`'.$table.'`.`'.$col.'`';
        else $column = '`'.$table.'`';

        if ($this->_where == '')
            $this->_where = 'WHERE ' . $column . ' IN ('. implode(',', $win) .')';
        else
            $this->_where .= ' OR ' . $column . ' IN ('. implode(',', $win) .')';

        return $this;
    }

    /**
     * Specifies the WHERE NOT IT clause\
     * Returns the Query builder
     * 
     * @param string $column 
     * @param string $values
     * @return QueryBuilder
     */
    public function whereNotIn($column, $values)
    {
        $win = array();
        
        if (is_string($values))
            $values = explode(',', $values);

        foreach ($values as $val)
        {
            //$val = trim($val);
            if (is_string($val)) $val = "'".$val."'";
            array_push($win, $val);
        }

        list ($table, $col) = explode('.', $column);
        if ($col) $column = '`'.$table.'`.`'.$col.'`';
        else $column = '`'.$table.'`';

        if ($this->_where == '')
            $this->_where = 'WHERE ' . $column . ' NOT IN ('. implode(',', $win) .')';
        else
            $this->_where .= ' AND ' . $column . ' NOT IN ('. implode(',', $win) .')';

        return $this;
    }

    /**
     * Specifies the WHERE BETWEEN clause\
     * Returns the Query builder
     * 
     * @param string $column 
     * @param array $values
     * @return QueryBuilder
     */
    public function whereBetween($column, $values)
    {
        $win = array();
        foreach ($values as $val)
        {
            if (is_string($val)) $val = "'".$val."'";
            array_push($win, $val);
        }

        list ($table, $col) = explode('.', $column);
        if ($col) $column = '`'.$table.'`.`'.$col.'`';
        else $column = '`'.$table.'`';

        if ($this->_where == '')
            $this->_where = 'WHERE ' . $column . ' BETWEEN '. $win[0] . ' AND ' . $win[1];
        else
            $this->_where .= ' AND ' . $column . ' BETWEEN '. $win[0] . ' AND ' . $win[1];

        return $this;
    }

    /**
     * Specifies the WHERE BETWEEN clause\
     * Returns the Query builder
     * 
     * @param string $column 
     * @param array $values
     * @return QueryBuilder
     */
    public function orWhereBetween($column, $values)
    {
        $win = array();
        foreach ($values as $val)
        {
            if (is_string($val)) $val = "'".$val."'";
            array_push($win, $val);
        }

        list ($table, $col) = explode('.', $column);
        if ($col) $column = '`'.$table.'`.`'.$col.'`';
        else $column = '`'.$table.'`';

        if ($this->_where == '')
            $this->_where = 'WHERE ' . $column . ' BETWEEN '. $win[0] . ' AND ' . $win[1];
        else
            $this->_where .= ' OR ' . $column . ' BETWEEN '. $win[0] . ' AND ' . $win[1];

        return $this;
    }

    /**
     * Specifies NULL value in WHERE clause\
     * Returns the Query builder
     * 
     * @param string $column 
     * @return QueryBuilder
     */
    public function whereNull($column, $ret=true)
    {
        if (is_array($column))
        {
            foreach ($column as $co)
            {
                $this->whereNull($co, false);
            }
            //return $this;
        }

        if ($this->_where == '')
            $this->_where = 'WHERE ' . $column . ' IS NULL';
        else
            $this->_where .= ' AND ' . $column . ' IS NULL';

        if ($ret) return $this;
    }

    /**
     * Add a "where" clause comparing two columns to the query
     *
     * @param  string  $first
     * @param  string  $operator
     * @param  string  $second
     * @param  string  $chain
     * @return QueryBuilder
     */
    public function whereColumn($first, $operator, $second=null, $chain='and')
    {
        if ($second==null)
        {
            $second = $operator;
            $operator = '=';
        }

        list ($table, $col) = explode('.', $first);
        if ($col) $first = '`'.$table.'`.`'.$col.'`';
        else $first = '`'.$table.'`';

        list ($table, $col) = explode('.', $second);
        if ($col) $second = '`'.$table.'`.`'.$col.'`';
        else $second = '`'.$table.'`';

        if ($this->_where == '')
            $this->_where = "WHERE $first $operator $second";
        else
            $this->_where .= " $chain $first $operator $second";

        return $this;
    }

    /**
     * Specifies the HAVING clause\
     * Returns the Query builder
     * 
     * @param string $column 
     * @param string $reference 
     * @param string $value 
     * @return QueryBuilder
     */
    public function having($reference, $operator, $value)
    {
        if (is_array($reference))
        {
            foreach ($reference as $co)
            {
                //var_dump($co); echo "<br>";
                list($var1, $var2, $var3) = $co;
                $this->where($var1, $var2, $var3, false);
            }
            return $this;
        }


        if ($value=='')
        {
            $value = $operator;
            $operator = '=';
        }

        list ($table, $col) = explode('.', $reference);
        if ($col) $reference = '`'.$table.'`.`'.$col.'`';
        else $reference = '`'.$table.'`';

        /* $vtype = 'i';
        if (is_string($value))
        {
            $vtype = 's';   
        }

        $this->_wherevals[] = array($vtype => $value); */
        if (is_string($value)) $value = "'$value'";

        if ($this->_having == '')
            $this->_having = 'HAVING ' . $reference . ' ' . $operator . ' ' . $value; // ' ?';
        else
            $this->_having .= ' AND ' . $reference . ' ' .$operator . ' ' . $value; // ' ?';

        return $this;
    }

    /**
     * Specifies the HAVING clause between to values\
     * Returns the Query builder
     * 
     * @param string $reference
     * @param array $values
     * @return QueryBuilder
     */
    public function havingBetween($reference, $values)
    {
        $win = array();
        foreach ($values as $val)
        {
            if (is_string($val)) $val = "'".$val."'";
            array_push($win, $val);
        }

        list ($table, $col) = explode('.', $reference);
        if ($col) $reference = '`'.$table.'`.`'.$col.'`';
        else $reference = '`'.$table.'`';

        if ($this->_having == '')
            $this->_having = 'HAVING ' . $reference . ' BETWEEN '. $win[0] . ' AND ' . $win[1];
        else
            $this->_having = ' AND ' . $reference . ' BETWEEN '. $win[0] . ' AND ' . $win[1];

        return $this;
    }

    private function _joinResult($side, $name, $column, $comparator, $ncolumn)
    {
        list($name, $as, $alias) = explode(' ', $name);

        $side = trim($side);
        $as = trim($as);
        $name = '`' . trim($name) . '`';
        $alias = ' `' . trim($alias) . '`';
        $column = '`' . trim($column) . '`';
        $ncolumn = '`' . trim($ncolumn) . '`';

        if ($this->_join == '')
            $this->_join = $side.' JOIN ' . $name . ($as?' as '.$alias:'') . ' on `' . $this->_table.'`.'.$ncolumn .' '.$comparator.' ' . ($as?$alias:$name).'.'.$column;
        else
            $this->_join .= ' ' . $side.' JOIN ' . $name . ($as?' as '.$alias:'') . ' on `' . $this->_table.'`.'.$ncolumn .' '.$comparator.' ' . ($as?$alias:$name).'.'.$column;
  
        return $this;
    }

    /**
     * Specifies the INNER JOIN clause\
     * Returns the Query builder
     * 
     * @param string $join_table 
     * @param string $column
     * @param string $comparator
     * @param string $join_column
     * @return QueryBuilder
     */
    public function join($join_table, $column, $comparator, $join_column)
    {
        return $this->_joinResult('INNER', $join_table, $column, $comparator, $join_column);
    }

    /**
     * Specifies the LEFT JOIN clause\
     * Returns the Query builder
     * 
     * @param string $join_table 
     * @param string $column
     * @param string $comparator
     * @param string $join_column
     * @return QueryBuilder
     */
    public function leftJoin($join_table, $column, $comparator, $join_column)
    {
        return $this->_joinResult('LEFT', $join_table, $column, $comparator, $join_column);
    }

    /**
     * Specifies the RIGHT JOIN clause\
     * Returns the Query builder
     * 
     * @param string $join_table 
     * @param string $column
     * @param string $comparator
     * @param string $join_column
     * @return QueryBuilder
     */
    public function rightJoin($join_table, $column, $comparator, $join_column)
    {
        return $this->_joinResult('RIGHT', $join_table, $column, $comparator, $join_column);
    }

    /**
     * Specifies the CROSS JOIN clause\
     * Returns the Query builder
     * 
     * @param string $join_table 
     * @param string $column
     * @param string $comparator
     * @param string $join_column
     * @return QueryBuilder
     */
    public function crossJoin($join_table, $column, $comparator, $join_column)
    {
        return $this->_joinResult('CROSS', $join_table, $column, $comparator, $join_column);
    }


    private function _joinSubResult($side, $query, $alias, $filter)
    {
        //var_dump($filter);
        $side = trim($side);
        //$filter = $filter->_join;
        $alias = '`' . trim($alias) . '`';

        if ($this->_join == '')
            $this->_join = $side.' JOIN (' . $query . ') as ' . $alias . ' ' . $filter;
        else
            $this->_join .= ' '.$side.' JOIN (' . $query . ') as ' . $alias . ' ' . $filter;
  
        return $this;
    }


    /**
     * INNER Joins as subquery\
     * Returns the Query builder
     * 
     * @param string $query 
     * @param string $alias
     * @param Query $filter
     * @return QueryBuilder
     */
    /* public function joinSub($query, $alias, $filter)
    {
        return $this->_joinSubResult('INNER', $query, $alias, $filter);
    } */
    public function joinSub($query, $as, $first, $operator = null, $second = null, $type = 'inner', $where = false)
    {
        $side = trim($type);

        $filter = '';

        if (!isset($second) && isset($operator))
        {
            $operator = '=';
            $second = $operator;
        }
        if (isset($second) && isset($operator))
        {
            $filter = ' ON ' . $first . ' ' . $operator . ' ' . $second;  
        }

        $alias = '`' . trim($as) . '`';

        if ($this->_join == '')
            $this->_join .= ' ' . $side.' JOIN (' . $query . ') as ' . $alias . $filter;
        else
            $this->_join .= ' ' . $side.' JOIN (' . $query . ') as ' . $alias . $filter;
  
        return $this;
    }

    /**
     * LEFT Joins as subquery\
     * Returns the Query builder
     * 
     * @param string $query 
     * @param string $alias
     * @param Query $filter
     * @return QueryBuilder
     */
    /* public function leftJoinSub($query, $alias, $filter)
    {
        return $this->_joinSubResult('LEFT', $query, $alias, $filter);
    } */

    /**
     * RIGHT Joins as subquery\
     * Returns the Query builder
     * 
     * @param string $query 
     * @param string $alias
     * @param Query $filter
     * @return QueryBuilder
     */
    /* public function rightJoinSub($query, $alias, $filter)
    {
        return $this->_joinSubResult('RIGHT', $query, $alias, $filter);
    } */


    /**
     * Specifies the UNION clause\
     * Returns the Query builder
     * 
     * @param QueryBuilder $query
     * @return QueryBuilder
     */
    public function union($query)
    {
        $this->_union = 'UNION ' . $query->toSql();

        return $this;

    }

    /**
     * Specifies the UNION ALL clause\
     * Returns the Query builder
     * 
     * @param QueryBuilder $query
     * @return QueryBuilder
     */
    public function unionAll($query)
    {
        $this->_union = 'UNION ALL ' . $query->toSql();

        return $this;

    }

    /**
     * Search in reconds for $value in several $colums\
     * Uses WHERE CONTACT($columns) LIKE $value\
     * Returns the records
     * 
     * @param string $columns
     * @param string $value
     * @return $array
     */
    public function search($var, $val)
    {
        $var = str_replace(',','," ",',$var);

        /* if ($this->_where == '')
            $this->_where = 'WHERE FIELD LIKE "%' . $val . '%" IN (' . $var . ')';
        else
            $this->_where .= ' OR FIELD LIKE "%' . $val . '%" IN (' . $var . ')'; */

        if ($this->_where == '')
            $this->_where = 'WHERE CONCAT(' . $var . ') LIKE "%'.$val.'%"';
        else
            $this->_where .= ' OR CONCAT(' . $var . ') LIKE "%'.$val.'%"';
            
        return $this;
    }

    /**
     * Specifies the GROUP BY clause\
     * Returns the Query builder
     * 
     * @param string $order
     * @return QueryBuilder
     */
    public function groupBy($val)
    {
        if ($this->_group == '')
            $this->_group = 'GROUP BY ' . $val;
        else
            $this->_group .= ', ' . $val;

        return $this;
    }

    /**
     * Orders the result by date or specified column\
     * Returns the Query builder
     * 
     * @return QueryBuilder
     */
    public function latest($column='created_at')
    {
        return $this->orderBy($column, 'DESC');
    }

    /**
     * Orders the result by date or specified column\
     * Returns the Query builder
     * 
     * @return QueryBuilder
     */
    public function oldest($column='created_at')
    {
        return $this->orderBy($column, 'ASC');
    }

    /**
     * Add a descending "order by" clause to the query.
     *
     * @return QueryBuilder
     */
    public function orderByDesc($column)
    {
        return $this->orderBy($column, 'DESC');
    }

    /**
     * Specifies the ORDER BY clause\
     * Returns the Query builder
     * 
     * @param string $order
     * @return QueryBuilder
     */
    public function orderBy($column, $order='ASC')
    {
        if ($this->_order == '')
            $this->_order = "ORDER BY $column $order";
        else
            $this->_order .= " ORDER BY $column $order";

        return $this;
    }

    /**
     * Specifies the ORDER BY clause without changing it\
     * Returns the Query builder
     * 
     * @param string $order
     * @return QueryBuilder
     */
    public function orderByRaw($order)
    {
        if ($this->_order == '')
            $this->_order = "ORDER BY $order";
        else
            $this->_order .= " ORDER BY $order";

        return $this;
    }

    /**
     * Alias to set the "limit" value of the query.
     *
     * @param  int  $value
     * @return QueryBuilder
     */
    public function take($value)
    {
        return $this->limit($value);
    }

    /**
     * Specifies the LIMIT clause\
     * Returns the Query builder
     * 
     * @param string $value
     * @return QueryBuilder
     */
    public function limit($value)
    {
        $this->_limit = $value;
        return $this;
    }

    /**
     * Alias to set the "offset" value of the query.
     *
     * @param  int  $value
     * @return QueryBuilder
     */
    public function skip($value)
    {
        return $this->offset($value);
    }

    /**
     * Specifies the LIMIT clause\
     * Returns the Query builder
     * 
     * @param string $value
     * @return QueryBuilder
     */
    public function offset($value)
    {
        $this->_offset = $value;
        return $this;
    }


    /**
     * Specifies the SET clause\
     * Allows array with key=>value pairs in $key\
     * Returns the Query builder
     * 
     * @param string $key
     * @param string $value
     * @return QueryBuilder
     */
    public function set($key, $val=null, $ret=true)
    {
        if (is_array($key))
        {
            foreach ($key as $k => $v)
            {
                array_push($this->_keys, $k);

                $camel = Helpers::snakeCaseToCamelCase($key);
                    
                if (method_exists($this->_parent, 'set'.ucfirst($camel).'Attribute'))
                {
                    //$cl = $this->_parent;
                    $fn = 'get'.ucfirst($camel).'Attribute';
                    //$v = call_user_func_array(array($cl, $fn), array($v));
                    $newmodel = new $this->_parent;
                    $v = $newmodel->$fn($v);
                }

                if (method_exists($this->_parent, $camel.'Attribute'))
                {
                    #echo "Value:$v<br>";
                    $fn = $camel.'Attribute';
                    $newmodel = new $this->_parent;
                    $nval = $newmodel->$fn($v, (array)$newmodel);
                    if (isset($nval['set'])) $v = $nval['set'];
                    #echo "NEW value:$v<br>";
                }

                if (is_string($v))
                    $v = "'".$v."'";

                array_push($this->_values, $v? $v : "NULL");
            }
        }
        else
        {
            array_push($this->_keys, $key);

            $camel = Helpers::snakeCaseToCamelCase($key);
            #echo "KEY: $camel"."Attribute<br>";

            if (method_exists($this->_parent, 'set'.ucfirst($camel).'Attribute'))
            {
                $fn = 'set'.ucfirst($camel).'Attribute';
                $newmodel = new $this->_parent;
                $val = $newmodel->$fn($val);
            }

            if (method_exists($this->_parent, $camel.'Attribute'))
            {
                #echo "Value:$val<br>";
                $fn = $camel.'Attribute';
                $newmodel = new $this->_parent;
                $nval = $newmodel->$fn($val, (array)$newmodel);
                if (isset($nval['set'])) $val = $nval['set'];
                #echo "NEW value:$val<br>";
            }

            if (is_string($val)) 
                $val = "'".$val."'";

            array_push($this->_values, isset($val)? $val : "NULL");
        }

        if ($ret) return $this;
    }

    /**
     * Saves the model in database
     * 
     * @return bool
     */
    public function save($values)
    {
        //dd($values); dd($this);
        //exit();

        if(!$values)
            throw new Exception('No values asigned');


        $final_vals = array();
        if (is_object($values) && class_exists(get_class($values)) && isset($this->_relationVars['relation_current']))
        {
            //dd($values); exit();
            $vals = array();
            foreach ($values as $key => $val)
                $vals[$key] = $val;

            $where = array($this->_relationVars['foreign'] => $this->_relationVars['relation_current']);

            return $this->updateOrCreate($where, $vals);

        }
        else
        {
            foreach ($values as $key => $val)
            {
                if (!(is_object($val) && class_exists(get_class($val))))
                {
                    $final_vals[$key] = $val;
                }
            }
            
            if (!$this->_collection->first())
            {
                //die("CREATE");
                return $this->_insert($final_vals);
            }
            else
            {
                //dd($final_vals);
                //dd($this);
                die("UPDATE");
                $this->_fillableOff = true;
                //dd($this->_where);

                $p_key = is_array($this->_primary)? $this->_primary[0] : $this->_primary;
                $pkeyval = $this->_collection->pluck($p_key)->first();
                //dd($pkeyval);exit();

                if (strpos($this->_where, $pkeyval)===false)
                {
                    //echo "NO HAY WHERE<br>";
                    $this->where($p_key, $pkeyval);
                }

                $res = $this->update($final_vals);

                $this->_fillableOff = false;
                return $res;
            }
        }


    }

    /**
     * Save the model and all of its relationships
     * 
     * @return bool
     */
    public function push($values, $new)
    {
        /* dd($values); dd($this);
        exit(); */
        
        $relations = array();

        if(!$values)
            throw new Exception('No values asigned');

        $final_vals = array();
        foreach ($values as $key => $val)
        {
            if (is_object($val) && class_exists(get_class($val)))
            {
                $relation = array();
                foreach ($val as $k => $v)
                    $relation[$k] = $v;

                $class = get_class($values);
                $class = new $class;
                $class->getInstance()->getQuery()->varsOnly = true;
                $_key = $class->getInstance()->getRouteKeyName();
                $data = $class->$key();
                $relation[$data->_relationVars['foreign']] = $values->$_key;
                $relation['__key'] = $data->_relationVars['foreign'];

                $relations[get_class($val)] = $relation;

            }
            else
            {
                $final_vals[$key] = $val;
            }
        }

        /* dd($final_vals);
        dd($relations);
        dd($this);
        dd($this->_primary);
        exit(); */

        /* $key = $this->_primary;
        //unset($final_vals[$key]);
        if ( !$this->updateOrCreate(array($key => $final_vals[$key]), $final_vals)) return false;
            
        foreach ($relations as $model => $values)
        {
            $key = $values['__key'];
            unset($values['__key']);
            //dd($model); dd($key); dd($values[$key]); dd($values); exit();
            if (! $model::updateOrCreate(array($key => $values[$key]), $values))
                return false;
        }
        return true; */

        if ($new)
        {
            //return $this->_insert($final_vals);
            //die("CREATE");

            if ( !$this->save($final_vals)) return false;
            //dd($relations);
            foreach ($relations as $model => $values)
            {
                $key = $values['__key'];
                unset($values['__key']);
                //dd($model); dd($key); dd($values[$key]); dd($values); exit();
                $m = new $model;

                //dd($values);
                //dd($m);exit();


                if (! $m->updateOrCreate(array($key => $values[$key]), $values))
                    return false;
                /* if (! $model::updateOrCreate(array($key => $values[$key]), $values))
                    return false; */
            }
            return true;
        }
        else
        {
            //$this->_fillableOff = true;
            $p_key = is_array($this->_primary)? $this->_primary[0] : $this->_primary;
            $this->where($p_key, $this->_collection->pluck($p_key)->first());
            //dd($this);            
            //die("UPDATE");


            if ( !$this->update($final_vals)) return false;
            
            foreach ($relations as $model => $values)
            {
                $key = $values['__key'];
                unset($values['__key']);
                //dd($model); dd($key); dd($values[$key]); dd($values); exit();
                $m = new $model;
                if (! $m->updateOrCreate(array($key => $values[$key]), $values))
                    return false;
                /* if (! $model::updateOrCreate(array($key => $values[$key]), $values))
                    return false; */
            }

            //$this->_fillableOff = false;
            return true;
        }

    }

    /**
     * INSERT a record or an array of records in database
     * 
     * @param array $record
     * @return bool
     */
    public function insert($record)
    {
        $isarray = false;
        foreach ($record as $key => $val)
        {
            if (!is_array($val))
            {
                $this->set($key, $val, false);
            }
            else
            {
                $isarray = true;
                return $this->_insert($val);
            }
        }
        if (!$isarray)
            return $this->_insert(array());

    }

    private function _insert($record)
    {
        
        foreach ($record as $key => $val)
            $this->set($key, $val, false);

        $sql = 'INSERT INTO `' . $this->_table . '` (' . implode(', ', $this->_keys) . ')'
                . ' VALUES (' . implode(', ', $this->_values) . ')';

        //echo $sql."<br>";
        $query = $this->_connector->query($sql);
    
        $last = array();
        for ($i=0; $i<count($this->_keys); ++$i)
        {
            $last[$this->_keys[$i]] = $this->_values[$i];
        }
        $this->_lastInsert = $last;
        //dump($last);

        $this->clear();
        
        return $query; //$this->_connector->error;
    }


    /**
     * INSERT IGNORE a record or an array of records in database
     * 
     * @param array $record
     * @return bool
     */
    public function insertOrIgnore($record)
    {
        $isarray = false;
        foreach ($record as $key => $val)
        {
            if (!is_array($val))
            {
                $this->set($key, $val, false);
            }
            else
            {
                $isarray = true;
                $this->_insertIgnore($val);
            }
        }
        if (!$isarray)
            $this->_insertIgnore(array());
    }

    private function _insertIgnore($record)
    {
        
        foreach ($record as $key => $val)
            $this->set($key, $val, false);

        $sql = 'INSERT INTO `' . $this->_table . '` (' . implode(', ', $this->_keys) . ')'
                . ' VALUES (' . implode(', ', $this->_values) . ')';

        //echo $sql."<br>";
        $query = $this->_connector->query($sql);
    
        $this->clear();
        
        return $query; //$this->_connector->error;
    }


    private function setValues($key, $val, $unset=false, $return=false)
    {
        global $preventSilentlyDiscardingAttributes;

        if (in_array($key, $this->_fillable) || $this->_fillableOff)
        {
            $this->set($key, $val, false);
        }
        else if (isset($this->_guarded) && !in_array($key, $this->_guarded))
        {
            $this->set($key, $val, false);
        }
        else
        {
            if ($unset)
                unset($record[$key]);

            if ($preventSilentlyDiscardingAttributes)
                throw new Exception("Add fillable property [$key] to allow mass assignment on [$this->_parent]");

        }
        if ($return)
            return $this; 
    }


    /**
     * Creates a new record in database\
     * Returns new record
     * 
     * @param array $record
     * @return Model
     */
    public function create($record = null)
    {
        #echo "CREATE<br>";
        #dump($record);
        if (is_object($record))
        {
            $arr = array();
            foreach ($record as $key => $val)
                $arr[$key] = $val;

            $record = $arr;
        }
        
        foreach ($record as $key => $val)
        {
            if (!is_object($val))
            {
                /* if (in_array($key, $this->_fillable) || $this->_fillableOff)
                    $this->set($key, $val, false);
                else if (isset($this->_guarded) && !in_array($key, $this->_guarded))
                    $this->set($key, $val, false);
                else
                    unset($record[$key]); */
                $this->setValues($key, $val, true, false);
            }
        }

        if (isset($this->_relationVars) && $this->_relationVars['relationship']=='morphOne'
            && isset($this->_relationVars['current_id']))
        {
            $this->set($this->_relationVars['foreign'], $this->_relationVars['current_id'], false);
            $this->set($this->_relationVars['relation_type'], $this->_relationVars['current_type'], false);
        }

        if(count($this->_values) == 0)
            return null;
        
        $this->checkObserver('creating', $record);

        if ($this->_insert(array()))
        {
            $this->checkObserver('created', $record);
            return $this->insertNewItem();
        }
        else
            return null;

    }

    /**
     * Updates a record in database
     * 
     * @param array|object $record
     * @return bool
     */
    public function update($record, $attributes=null)
    {
        //echo "UPDATE<br>";
        //dd($record); dd($attributes); dd($this); exit();

        if (isset($attributes))
        {
            foreach ($this->_primary as $primary)
            {
                if (!isset($attributes[$primary]))
                    throw new Exception("Error in model's primary key");
                    
                $this->where($primary, $attributes[$primary], false);
            }
            //$key = $this->_primary;
            //if (isset($attributes->$key))
            //else throw new Exception("Error updating existent model");
        }

        foreach ($record as $key => $val)
        {
            /* if ($record->$key != $attributes[$key] || !isset($attributes[$key]))
            { */
            if (!is_object($val))
            {
                /* if (in_array($key, $this->_fillable) || $this->_fillableOff)
                    $this->set($key, $val, false);
                else if (isset($this->_guarded) && !in_array($key, $this->_guarded))
                    $this->set($key, $val, false); */
                $this->setValues($key, $val, false, false);
            }

        }

        //dd($this); exit();
        /* foreach ($record as $key => $val)
            $this->set($key, $val, false); */
    
        if ($this->_where == '')
            throw new Exception('WHERE not assigned. Use updateAll() if you want to update all records');

        if (!$this->_values)
           throw new Exception('No values assigned for update');


        $valores = array();
        
        for ($i=0; $i < count($this->_keys); $i++) {
            array_push($valores, $this->_keys[$i] . "=" . $this->_values[$i]);
        }

        if ($this->_softDelete && !$this->_withTrashed)
            $this->whereNull('deleted_at');

        $sql = 'UPDATE `' . $this->_table . '` SET ' . implode(', ', $valores) . ' ' . $this->_where;

        //dd($sql); exit();
        #var_dump($this->_wherevals);
        #echo $sql."::";var_dump($this->_wherevals);echo "<br>";
        #exit();
        $query = $this->_connector->query($sql, $this->_where, $this->_wherevals);

        $this->clear();
        
        return $query; //$this->_connector->error;
    }

    /**
     * Create or update a record matching the attributes, and fill it with values
     * 
     * @param  array  $attributes
     * @param  array  $values
     * @return string
     */
    public function updateOrInsert($attributes, $values)
    {

        $this->clear();
        foreach ($attributes as $key => $val)
        {
           $this->where($key, $val, false);
        }
        
        $sql = 'SELECT * FROM `' . $this->_table . '` '. $this->_where . ' LIMIT 0, 1';
        $res = $this->_connector->execSQL($sql, $this->_wherevals);
        $res = $res[0];

        if ($res)
        {
            return $this->update($values);
        }
        else
        {
            $new = array_merge($attributes, $values);
            return $this->insert($new);
        }

    }

    /**
     * Create or update a record matching the attributes, and fill it with values\
     * Returns the record
     * 
     * @param  array  $attributes
     * @param  array  $values
     * @return Model
     */
    public function updateOrCreate($attributes, $values)
    {

        $this->clear();
        foreach ($values as $key => $val)
        {
            /* if (in_array($key, $this->_fillable) || $this->_fillableOff)
                $this->set($key, $val, false);
            else if (isset($this->_guarded) && !in_array($key, $this->_guarded))
                $this->set($key, $val, false);
            else
                unset($values[$key]); */
            $this->setValues($key, $val, true, false);
        }
        //var_dump($values);

        $this->clear();
        foreach ($attributes as $key => $val)
        {
           $this->where($key, $val, false);
        }
        
        $sql = 'SELECT * FROM `' . $this->_table . '` '. $this->_where . ' LIMIT 0, 1';
        //echo $sql;
        $res = $this->_connector->execSQL($sql, $this->_wherevals);
        $res = $res[0];

        if ($res)
        {
            //dd($res);dd($values);
            if ($this->update($values))
            {
                foreach($values as $key => $val)
                    $res->$key = $val;

                return $this->insertUnique($res);
            }
            else
                return null;

        }
        else
        {
            $new = array_merge($attributes, $values);
            return $this->create($new);
        }

    }

    /**
     * Uses REPLACE clause\
     * Updates a record using PRIMARY KEY OR UNIQUE\
     * If the record doesn't exists then creates a new one
     * 
     * @param array $record
     * @return bool
     */
    public function insertReplace($record)
    {
        $isarray = false;
        #$where = $this->_where;
        #$wherevals = $this->_wherevals;

        foreach ($record as $key => $val)
        {
            if (!is_array($val))
            {
                $this->set($key, $val, false);
            }
            else
            {
                #$this->_where = $where;
                #$this->_wherevals = $wherevals;

                $isarray = true;
                $this->_insertReplace($val);
            }
        }
        if (!$isarray)
            $this->_insertReplace(array());
    }

    private function _insertReplace($record)
    {
        //global $database;

        foreach ($record as $key => $val)
            $this->set($key, $val, false);
        
        $sql = 'REPLACE INTO `' . $this->_table . '` (' . implode(', ', $this->_keys) . ')'
                . ' VALUES (' . implode(', ', $this->_values) . ')';

        //echo $sql;
        $query = $this->_connector->execSQL($sql, $this->_wherevals);

        $this->clear();
        
        return $query; //$this->_connector->error;
    }



    /**
     * UDPATE the current records in database
     * 
     * @param array $values
     * @return bool
     */
    public function updateAll($values)
    {
        //global $database;

        foreach ($values as $key => $val)
            $this->set($key, $val, false);

        $valores = array();

        for ($i=0; $i < count($this->_keys); $i++) {
            array_push($valores, $this->_keys[$i] . "=" . $this->_values[$i]);
        }

        $sql = 'UPDATE `' . $this->_table . '` SET ' . implode(', ', $valores);

        $query = $this->_connector->execSQL($sql, $this->_wherevals);

        $this->clear();
        
        return $query; //$this->_connector->error;
    }

    /**
     * DELETE the current records from database\
     * Returns error if WHERE clause was not specified
     * 
     * @return bool
     */
    public function delete()
    {
        if ($this->_where == '')
            throw new Exception('WHERE not assigned');

        $sql = 'DELETE FROM `' . $this->_table . '` ' . $this->_where;

        $query = $this->_connector->query($sql, $this->_wherevals);

        $this->clear();
        
        return $query; //$this->_connector->error;
    }


    /**
     * Include trashed models in Query
     * 
     * @return QueryBuilder
     */
    public function withTrashed()
    {
        if (!$this->_softDelete)
            throw new Exception('Tryin to use softDelete method on a non-softDelete Model');

        $this->_withTrashed = true;
        return $this;
    }

    /**
     * SOFT DELETE the current records from database
     * 
     * @return bool
     */
    public function softDeletes($record)
    {
        $date = date("Y-m-d H:i:s");

        foreach ($this->_primary as $primary)
        {
            if (!isset($record[$primary]))
                throw new Exception("Error in model's primary key");
                
            $this->where($primary, $record[$primary], false);
        }

        $sql = 'UPDATE `' . $this->_table . '` SET `deleted_at` = ' . "'$date'" . ' ' . $this->_where;

        $query = $this->_connector->execSQL($sql, $this->_where, $this->_wherevals);

        $this->clear();
        
        return $query;
    }

    /**
     * RESTORE the current records from database
     * 
     * @return bool
     */
    public function restore($record=null)
    {

        if (isset($record))
        {
            foreach ($this->_primary as $primary)
            {
                if (!isset($record[$primary]))
                    throw new Exception("Error in model's primary key");
                    
                $this->where($primary, $record[$primary], false);
            }
        }

        $sql = 'UPDATE `' . $this->_table . '` SET `deleted_at` = NULL ' . $this->_where;

        //dd($sql); exit();

        $query = $this->_connector->execSQL($sql, $this->_where, $this->_wherevals);

        $this->clear();
        
        return $query;
    }

    /**
     * Permanently deletes the current record from database
     * 
     * @return bool
     */
    public function forceDelete($record)
    {
        foreach ($this->_primary as $primary)
        {
            if (!isset($record[$primary]))
                throw new Exception("Error in model's primary key");
                
            $this->where($primary, $record[$primary], false);
        }
        
        $sql = 'DELETE FROM `' . $this->_table . '` ' . $this->_where;

        $query = $this->_connector->execSQL($sql, $this->_wherevals);

        $this->clear();
        
        return $query;
    }


    /**
     * Truncates the current table
     * 
     * @return bool
     */
    public function truncate()
    {
        $sql = 'TRUNCATE TABLE `' . $this->_table . '`';

        $query = $this->_connector->query($sql);

        $this->clear();
        
        return $query; //$this->_connector->error;
    }


    /**
     * Returns the first record from query\
     * Returns 404 if not found
     * 
     * @return object
     */
    public function firstOrFail()
    {        
        if ($this->first())
            return $this->first();

        else
            abort(404);
    }


    /**
     * Returns the first record from query
     * 
     * @return Model
     */
    public function first()
    {
        if ($this->_softDelete && !$this->_withTrashed)
            $this->whereNull('deleted_at');


        $this->limit(1)->offset(0);

        $sql = $this->buildQuery();

        //echo $sql."<br>";
        $this->_connector->execSQL($sql, $this->_wherevals, $this->_collection);

        if ($this->_collection->count()>0)
            $this->processEagerLoad();

        //$this->clear();

        if ($this->_collection->count()==0)
            return NULL;

        return $this->insertUnique($this->_collection[0]);
    }


    /**
     * Retrieves the first record matching the attributes, and fill it with values (if asssigned)\
     * If the record doesn't exists creates a new one\
     * 
     * @param  array  $attributes
     * @param  array  $values
     * @return Model
     */
    public function firstOrNew($attributes, $values=array())
    {
        //$this->_collection = array();

        $this->clear();
        foreach ($attributes as $key => $val)
        {
            $this->where($key, $val, false);
        }

        $sql = $this->_method . ' `' . $this->_table . '` ' . $this->_join . ' ' . $this->_where 
                . $this->_union . ' LIMIT 0, 1';

        $this->_connector->execSQL($sql, $this->_wherevals, $this->_collection);

        if ($this->_collection->count()>0)
            $this->processEagerLoad();

        $item = null;

        if (!isset($this->_collection[0]))
        {
            $item = new $this->_parent; //stdClass();
            $this->clear();
            foreach ($attributes as $key => $val)
                $item->$key = $val;
        }
        else
        {
            $item = $this->_collection[0];
        }

        foreach ($values as $key => $val)
            $item->$key = $val;

        return $this->insertUnique($item, $this->_collection->count()==0);
    }


    /**
     * Retrieves the first record matching the attributes, and fill it with values (if asssigned)\
     * If the record doesn't exists creates a new one and persists in database\
     * 
     * @param  array  $attributes
     * @param  array  $values
     * @return Model
     */
    public function firstOrCreate($attributes, $values=array())
    {
        $this->clear();
        foreach ($attributes as $key => $val)
        {
            $this->where($key, $val, false);
        }

        $sql = $this->_method . ' `' . $this->_table . '` ' . $this->_join . ' ' . $this->_where 
                . $this->_union . ' LIMIT 0, 1';

        $this->_connector->execSQL($sql, $this->_wherevals, $this->_collection);

        if ($this->_collection->count()>0)
            $this->processEagerLoad();

        $item = null;

        if (!isset($this->_collection[0]))
        {
            $item = new $this->_parent; //stdClass();
            $item = $this->create(array_merge($attributes, $values));
            $item->_setRecentlyCreated(true);
        }
        else
        {
            $item = $this->insertUnique($this->_collection[0]);
            foreach ($values as $key => $val)
                $item->$key = $val;
        }

        return $item;

    }


    public function find($val)
    {
        //$this->_where = 'WHERE ' . $this->_primary . ' = "' . $val . '"';

        $val = is_array($val)? $val : array($val);
        $this->_where = '';
        $i = 0;
        foreach ($this->_primary as $primary)
        {
            $this->where($primary, $val[$i]);
            ++$i;
        }

        return $this->first();
    }

    public function findOrFail($val)
    {
        //$this->_where = 'WHERE ' . $this->_primary . ' = "' . $val . '"';
        $val = is_array($val)? $val : array($val);
        $this->_where = '';
        $i = 0;
        foreach ($this->_primary as $primary)
        {
            $this->where($primary, $val[$i]);
            ++$i;
        }

        $res = $this->first();

        if ($res)
            return $res;

        else
            abort(404);
    }


    private function insertNewItem()
    {
        $last = $this->_connector->getLastId();
        //dump($last); dump($this);

        if ($last==0)
        {
            $keys = is_array($this->_primary) ? $this->_primary : array($this->_primary);

            $this->clear();
            foreach ($keys as $key)
            {
                $this->where($key, $this->_lastInsert[$key]);
            }
            //dump($this);
            $new = $this->first();

        }
        else
        {
            $new = $this->find($last);
        }        
        
        return $this->insertUnique($new);
    }


    private function insertUnique($data, $new=false)
    {
        $class = $this->_parent;
        $item = new $class;

        //dump($data);

        /* $itemKey = $item->getRouteKeyName();

        if (!isset($data->$itemKey) && isset($new))
        {
            $data = $this->find($this->_connector->getLastId());
        } */

        foreach ($data as $key => $val)
        {
            $camel = Helpers::snakeCaseToCamelCase($key);

            if (method_exists($this->_parent, 'get'.ucfirst($camel).'Attribute'))
            {
                $fn = 'get'.ucfirst($camel).'Attribute';
                $val = $item->$fn($val);
            }
            if (method_exists($this->_parent, $camel.'Attribute'))
            {
                $fn = $camel.'Attribute';
                $nval = $item->$fn($val, (array)$item);
                if (isset($nval['get'])) $val = $nval['get'];
            }

            if ($key!='deleted_at' || ($key=='deleted_at' && !$this->_softDelete))
                $item->$key = $val;

            //if (in_array($key, is_array($this->_primary)? $this->_primary : array($this->_primary)))

            if (!is_object($val))
            {
                if ($key!='deleted_at' && !$new)
                    $item->_setOriginalKey($key, $val);

                elseif ($key=='deleted_at' && !$this->_softDelete && !$new)
                    $item->_setOriginalKey($key, $val);

                elseif ($key=='deleted_at' && $this->_softDelete)
                    $item->_setTrashed($val);
            }

        }
        $this->__new = false;
        $item->_setOriginalRelations($this->_eagerLoad);

        //ddd($item);

        return $item;
    }

    private function insertData($data)
    {
        $col = new Collection($this->_parent, $this->_hidden); //get_class($this->_parent));
        $col->_modelKeys = $this->_primary;
        $class = $this->_parent; //get_class($this->_parent);

        foreach ($data as $arr)
        {
            
            $item = new $class(true);
            foreach ($arr as $key => $val)
            {
                $camel = Helpers::snakeCaseToCamelCase($key);

                if (method_exists($this->_parent, 'get'.ucfirst($camel).'Attribute'))
                {
                    $fn = 'get'.ucfirst($camel).'Attribute';
                    /* $newmodel = new $this->_parent;
                    $val = $newmodel->$fn($val); */
                    $val = $item->$fn($val);
                }

                if (method_exists($this->_parent, $camel.'Attribute'))
                {
                    $fn = $camel.'Attribute';
                    $nval = $item->$fn($val, (array)$arr);
                    if (isset($nval['get'])) $val = $nval['get'];
                }

                if ($key!='deleted_at' || ($key=='deleted_at' && !$this->_softDelete))
                    $item->$key = $val;

                //dump($key); dump($val);

                if (!is_object($val))
                {
                    if ($key!='deleted_at')
                        $item->_setOriginalKey($key, $val);
    
                    elseif ($key=='deleted_at' && !$this->_softDelete)
                        $item->_setOriginalKey($key, $val);
    
                    elseif ($key=='deleted_at' && $this->_softDelete)
                        $item->_setTrashed($val);
                }
    
                $item->_setOriginalRelations($this->_eagerLoad);
            }
    
            $col[] = $item;
        }

        if (isset($data->pagination))
            $col->pagination = $data->pagination;

        return $col;
       
    }

    /**
     * Return all records from current query
     * 
     * @return Collection
     */
    public function all()
    {
        return $this->get();
    }

    /**
     * Return all records from current query
     * 
     * @return Collection
     */
    public function get()
    {
        if ($this->_softDelete && !$this->_withTrashed)
            $this->whereNull('deleted_at');

        $sql = $this->buildQuery();

        //echo $sql."<br>"; var_dump($this->_wherevals);

        $this->_connector->execSQL($sql, $this->_wherevals, $this->_collection);

        if ($this->_collection->count()==0)
            return $this->_collection;

        //dump($this);

        $this->processEagerLoad();

        $this->clear();

        return $this->insertData($this->_collection);

    }
    
    /**
     * Return all records from current query\
     * Limit the resutl to number of $records\
     * Send Pagination values to View class 
     * 
     * @param int $records
     * @return Collection
     */
    public function paginate($cant = 10)
    {

        $filtros = $_GET;

        $pagina = $filtros['p']>0? $filtros['p'] : 1;
        $offset = ($pagina-1) * $cant; 

        if ($this->_softDelete && !$this->_withTrashed)
            $this->whereNull('deleted_at');

        $this->_limit = null;
        $this->_offset = null;

        $sql = $this->buildQuery() . " LIMIT $cant OFFSET $offset";
        

        $this->_connector->execSQL($sql, $this->_wherevals, $this->_collection);

        if ($this->_collection->count()==0)
        {
            //View::setPagination(null);
            return $this->_collection;
        }
        
        $records = 'select count(*) AS total from (' . $this->buildQuery() .') final';
        
        $query = $this->_connector->execSQL($records, $this->_wherevals);

        $pages = isset($query[0])? $query[0]->total : 0;

        $pages = ceil($pages / $cant);

        /* unset($filtros['ruta']);

        $otros = $filtros;
        unset($otros['pagina']);
        foreach($filtros as $key => $value)
            if (!$value) unset($otros[$key]); */

        $pagina = (int)$pagina;
        $pages = (int)$pages;
        
        //$pagination = new arrayObject();
        if ($pages>1)
        {
            $pagination = new arrayObject();
            $pagination->first = $pagina<=1? null : 'p=1';
            $pagination->second = $pagina<=1? null : 'p='.($pagina-1);
            $pagination->third = $pagina==$pages? null : 'p='.($pagina+1);
            $pagination->fourth = $pagina==$pages? null : 'p='.$pages;
            //View::setPagination($pagination);
            $this->_collection->pagination = $pagination;
        }
        /* else
        {
            View::setPagination(null);
        } */


        $this->processEagerLoad();
        
        $this->clear();

        //return $this->_collection;
        return $this->insertData($this->_collection);

    }


    public function fresh($original, $relations=null)
    {
        $keys = is_array($this->_primary) ? $this->_primary : array($this->_primary);
        $this->_where = '';
        
        foreach ($keys as $key)
        {
            $this->where($key, $original[$key]);
        }

        $this->_eagerLoad = $relations;

        return $this->first();
    }


    /**
     * Re-hydrate the existing model using fresh data from the database
     * 
     * @return Model
     */
    public function refresh($original, $relations=null)
    {
        $keys = is_array($this->_primary) ? $this->_primary : array($this->_primary);
        $this->_where = '';
        
        foreach ($keys as $key)
        {
            $this->where($key, $original[$key]);
        }

        $this->_eagerLoad = $relations;

        return $this->first();
    }


    /**
     * Executes the SQL $query
     * 
     * @param string $query
     * @return msqli_result|bool
     */
    public function query($sql)
    {
        return $this->_connector->query($sql);
    }


    public function setForeign($key)
    {
        $this->_foreign = $key;
        return $this;
    }

    /* public function setPrimary($key)
    {
        $this->_primary = $key;
        return $this;
    } */

    /* public function setRelationship($key)
    {
        $this->_relationship = $key;
        return $this;
    } */

    /* public function setParent($key)
    {
        $this->_parent = $key;
        //return $this;
    } */

    public function setConnector($connector)
    {
        $this->_connector = $connector;
        return $this;
    }


    public function hasOne($class, $foreign, $primary)
    {
        return Relations::processRelationship($class, $foreign, $primary, 'hasOne', $this);
    }

    public function hasMany($class, $foreign, $primary)
    {
        return Relations::processRelationship($class, $foreign, $primary, 'hasMany', $this);
    }

    public function belongsTo($class, $foreign, $primary)
    {
        return Relations::processRelationship($class, $foreign, $primary, 'belongsTo', $this);
    }


    public function hasOneThrough($class, $classthrough, $foreignthrough, $foreign, $primary, $primarythrough)
    {
        return Relations::processRelationshipThrough($class, $classthrough, $foreignthrough, $foreign, $primary, $primarythrough, 'hasOneThrough', $this);
    }

    public function hasManyThrough($class, $classthrough, $foreignthrough, $foreign, $primary, $primarythrough)
    {
        return Relations::processRelationshipThrough($class, $classthrough, $foreignthrough, $foreign, $primary, $primarythrough, 'hasManyThrough', $this);
    }

    public function belongsToMany($class, $foreign, $primary, $foreignthrough, $primarythrough)
    {
        //dump(func_get_args());die();
        $array = array($this->_parent, $class);
        sort($array);                 
        $classthrough = Helpers::camelCaseToSnakeCase(implode('', $array), false);
        if (!$foreignthrough) $foreignthrough = Helpers::camelCaseToSnakeCase($this->_parent, false).'_'.$this->_routeKey;
        if (!$primarythrough) $primarythrough = Helpers::camelCaseToSnakeCase($class, false).'_'.$this->_routeKey;

        if (!$foreign) $foreign = 'id';
        if (!$primary) $primary = is_array($this->_primary)? $this->_primary[0] : $this->_primary;
        //dd ($foreignthrough); dd($primarythrough);

        return Relations::processRelationshipThrough($class, $classthrough, $foreignthrough, 
                    $foreign, $primary, $primarythrough, 'belongsToMany', $this);

    }

    public function morphOne($class, $method)
    {
        return Relations::processMorphRelationship($class, $method, 'morphOne', $this);
    }

    public function morphMany($class, $method)
    {
        return Relations::processMorphRelationship($class, $method, 'morphMany', $this);
    }

    public function morphToMany($class, $method)
    {
        return Relations::processMorphRelationshipThrough($class, $method, 'morphToMany', $this);
    }

    public function morphedByMany($class, $method)
    {
        return Relations::processMorphRelationshipThrough($class, $method, 'morphedByMany', $this);
    }

    public function morphTo()
    {
        return Relations::processMorphRelationshipTo($this);
    }


    private function addRelation(&$eager_load, $relation, $constraints=null)
    {
        $keys = explode('.', $relation);

        $last_key = array_pop($keys);

        while ($arr_key = array_shift($keys)) {
            if (!array_key_exists($arr_key, $eager_load)) {
                $eager_load[$arr_key] = array();
            }
            $eager_load = &$eager_load[$arr_key];
        }

        $eager_load[$last_key]['_constraints'] = $constraints;
    }


    /**
     * Adds records from a sub-query inside the current records\
     * Check Laravel documentation
     * 
     * @return QueryBuilder
     */
    public function with($relations)
    {
        if (is_string($relations))
            $relations = array($relations);

        //dd($relations);
        
        foreach ($relations as $relation => $values)
        {
            //dump($relation); dump($values);
            /* if (is_string($values))
            {
                $this->addRelation($this->_eagerLoad, $values);
            }
            elseif (is_null($values))
            {
                $this->addRelation($this->_eagerLoad, $relation);
            }
            elseif (is_object($values))
            {
                $values->_where = str_replace("`".$values->_table."`.", "`_child_table_`.", $values->_where);
                $this->addRelation($this->_eagerLoad, $relation, $values);
            } */

            if (is_string($values) && strpos($values, '@')===false)
            {
                $this->addRelation($this->_eagerLoad, $values);
            }
            elseif (is_array($values))
            {
                foreach ($values as $val)
                {
                    $this->addRelation($this->_eagerLoad, $relation.'.'.$val);
                }
            }
            elseif (is_null($values))
            {
                $this->addRelation($this->_eagerLoad, $relation);
            }
            else //if (is_object($values))
            {
                $this->addRelation($this->_eagerLoad, $relation, $values);
            }
            /* else
            {
                array_push($this->_eagerLoad, array('relation' => trim($relation), 'constraints' => $values ));
            } */
        }
        //echo "<br>";var_dump($this->_eagerLoad);echo "<br>";
        //dd($this->_eagerLoad);
        //dd($this);
        return $this;
    }


    private function processEagerLoad()
    {
        if (count($this->_eagerLoad) == 0) return;
        
        //dump($this->_eagerLoad);

        foreach ($this->_eagerLoad as $key => $val)
        {
            //echo "RELATION $key: ";var_dump($val); echo "<br>";
            $class = new $this->_parent;
            $class->setQuery($this);

            //dd($class->getQuery());

            $class->getQuery()->_relationName = $key;
            $class->getQuery()->_relationColumns = '*';
            $class->getQuery()->_extraQuery = isset($val['_constraints']) ? $val['_constraints'] : null;
            //unset($val['_constraints']);
            $class->getQuery()->_nextRelation = $val;

            if (strpos($key, ':')>0) {
                list($key, $columns) = explode(':', $key);
                $class->getQuery()->_relationColumns = explode(',', $columns);
                $class->getQuery()->_relationName = $key;
            }

            $res = $class->$key();

            Relations::insertRelation($this, $res, $key); //$real_relation);
        }

    }


    public function load($relations)
    {
        $relations = is_string($relations) ? func_get_args() : $relations;
        
        $this->with($relations);
        $this->processEagerLoad();

        return $this->_collection;
    }


    public function setHasConstraint($value)
    {
        if (!$value)
            unset($this->_hasConstraints);
        else
            $this->_hasConstraints = $value;
    }

    public function _has($relation, $constraints=null, $comparator=null, $value=null)
    {
        //echo "HAS: ".$relation. " :: ".$constraints."<br>";
        //dump($constraints);
        $data = null;
        
        $newparent = new $this->_parent;
        
        if (strpos($relation, '.')>0)
        {
            $data = explode('.', $relation);
            $relation = array_pop($data);
            $parent_relation = array_shift($data);
        }
        
        $newparent->getQuery()->varsOnly = true;
        //$newparent->$relation();
        $data = $newparent->$relation();

        $childtable = $data->_table;
        $foreign = $data->_relationVars['foreign'];
        $primary = $data->_relationVars['primary'];

        $filter = '';
        if (isset($constraints) && !is_array($constraints) && strpos($constraints, '@')!==false)
        {
            list($class, $method, $params) = getCallbackFromString($constraints);
            array_shift($params);
            call_user_func_array(array($class, $method), array_merge(array(&$data), $params));

            //$new_where = str_replace('`'.$data->_table.'`.', '`'.$data->_table.'`.', $data->_where);
            //$new_where = str_replace('`_child_table_`.', '`'.$data->_table.'`.', $new_where);
            //echo "NEW_WHERE: $new_where<br>";
            $filter = str_replace('WHERE', ' AND', $data->_where);
        } 
        elseif (isset($constraints) && !is_array($constraints) && strpos($constraints, '@')===false)
        {
            $filter = " AND `$data->_table`.`$constraints` $comparator $value";
            $comparator = null;
        }
        
        /* elseif (isset($constraints) && is_array($constraints))
        {
            foreach ($constraints as $exq)
            {
                $new_where = str_replace('`'.$exq->_table.'`.', '`'.$data->_table.'`.', $exq->_where);
                $new_where = str_replace('`_child_table_`.', '`'.$data->_table.'`.', $exq->_where);
                $filter .= str_replace('WHERE', ' AND', $new_where);
            }
        }  */

        if (isset($constraints) && strpos($constraints, '@')!==false)
            $this->_wherevals = $constraints->_wherevals;


        if (!$comparator)
            $where = 'EXISTS (SELECT * FROM `'.$childtable.'` WHERE `'.
                $this->_table.'`.`'.$primary.'` = `'.$childtable.'`.`'.$foreign.'`' . $filter . ')';
        else
            $where = ' (SELECT COUNT(*) FROM `'.$childtable.'` WHERE `'.
                $this->_table.'`.`'.$primary.'` = `'.$childtable.'`.`'.$foreign.'`' . $filter  . ') '.$comparator.' '.$value;

        if (isset($data->_relationVars['classthrough']))
        {
            $ct = $data->_relationVars['classthrough'];
            $cp = $data->_relationVars['foreignthrough'];
            $cf = $data->_relationVars['primarythrough'];

            if (!$comparator)
                $where = 'EXISTS (SELECT * FROM `'.$childtable.'` INNER JOIN `'.$ct.'` ON `'.$ct.'`.`'.$cf.
                    '` = `'.$childtable.'`.`'.$foreign.'` WHERE `'.
                    $this->_table.'`.`'.$primary.'` = `'.$ct.'`.`'.$cp.'`' . $filter . ')';
            else
                $where = '(SELECT COUNT(*) FROM `'.$childtable.'` INNER JOIN `'.$ct.'` ON `'.$ct.'`.`'.$cf.
                    '` = `'.$childtable.'`.`'.$foreign.'` WHERE `'.
                    $this->_table.'`.`'.$primary.'` = `'.$ct.'`.`'.$cp.'`' . $filter . ') '.$comparator.' '.$value;

        }

        //$this->_extraquery = $extraquery;

        if ($this->_where == '')
            $this->_where = 'WHERE ' . $where;
        else
            $this->_where .= ' AND ' . $where;

        //echo "<br>".$this->toSql()."<br>";
        return $this;
    }

    /**
     * Filter current query based on relationships\
     * Check Laravel documentation
     * 
     * @return QueryBuilder
     */
    public function has($relation, $comparator=null, $value=null)
    {
        return $this->_has($relation, null, $comparator, $value);
    }


    /**
     * Filter current query based on relationships
     * Check Laravel documentation
     * 
     * @param string $relation
     * @param string $colum
     * @param string $comparator
     * @param string|int $value
     * @return QueryBuilder
     */
    public function whereRelation($relation, $column, $comparator=null, $value=null)
    {
        return $this->_has($relation, $column, $comparator, $value);
    }


    /**
     * Filter current query based on relationships\
     * Allows to specify additional filters\
     * Filters can be nested\
     * Check Laravel documentation
     * 
     * @param string $relation
     * @param Query $filter
     * @param string $comparator
     * @param string|int $value
     * @return QueryBuilder
     */
    public function whereHas($relation, $filter=null, $comparator=null, $value=null)
    {
        return $this->_has($relation, $filter, $comparator, $value);
    }

    /**
     * Filter current query based on relationships\
     * Allows to specify additional filters\
     * Filters can be nested\
     * Check Laravel documentation
     * 
     * @param string $relation
     * @param Query $filter
     * @return QueryBuilder
     */
    public function withWhereHas($relation, $constraints=null)
    {
        $this->_hasConstraints = array('relation' => $relation, 'constraints' => $constraints);
        return $this->with(array($relation => $constraints))
                ->_has($relation, $constraints);
    }


    /**
     * Indicate that the relation is the latest single result of a larger one-to-many relationship.
     *
     * @param  string|null  $column
     * @param  string|null  $relation
     * @return QueryBuilder
     */
    public function latestOfMany($column = 'id', $relation = null)
    {
        return $this->ofMany($column, 'MAX', $relation, 'latestOfMany');
    }

    /**
     * Indicate that the relation is the oldest single result of a larger one-to-many relationship.
     *
     * @param  string|null  $column
     * @param  string|null  $relation
     * @return QueryBuilder
     */
    public function oldestOfMany($column = 'id', $relation = null)
    {
        return $this->ofMany($column, 'MIN', $relation, 'oldestOfMany');
    }


    /**
     * Indicate that the relation is a single result of a larger one-to-many relationship.
     *
     * @param  string|null  $column
     * @param  string|null  $aggregate
     * @param  string|null  $relation
     * @return QueryBuilder
     */
    public function ofMany($column = 'id', $aggregate = 'MAX', $relation = null, $relationName)
    {
        $relationship = $this->_relationVars['relationship'];

        $this->_relationVars['oneOfMany'] = true;

         
        $query = "SELECT MAX(`".$this->_table."`.`".$this->_primary[0]."`) as ".
            $this->_primary[0]."_aggregate, `".$this->_table."`.`".$this->_relationVars['foreign']."` 
            FROM ".$this->_table." INNER JOIN (SELECT ".$aggregate."(`".$this->_table."`.`".$column."`) as 
            `".$column."_aggregate`, `".$this->_table."`.`".$this->_relationVars['foreign']."` 
            FROM ".$this->_table." !WHERE! GROUP BY `".$this->_table."`.`".
            $this->_relationVars['foreign']."`) AS `$relationName` on `$relationName`.`".$column."_aggregate` = `".
            $this->_table."`.`".$column."` AND `$relationName`.`".$this->_relationVars['foreign']."` = 
            `".$this->_table."`.`".$this->_relationVars['foreign']."` GROUP BY 
            `".$this->_table."`.`".$this->_relationVars['foreign']."`";

        $filter = "ON `$relationName`.`".$this->_primary[0]."_aggregate` = `$this->_table`.`".$this->_primary[0]."` 
        AND `$relationName`.`".$this->_relationVars['foreign']."` = 
        `".$this->_table."`.`".$this->_relationVars['foreign']."`";

        $this->_joinSubResult('INNER', $query, $relationName, $filter);


        if ($relationship == 'hasOneThrough' || $relationship == 'hasManyThrough')
            $this->_where = str_replace($this->_table, $this->_relationVars['classthrough'], $this->_where);

        return $this;

    }


    /**
     * Add a "belongs to" relationship where clause to the query.
     * Check Laravel Documentation
     * 
     * @return QueryBuilder
     */
    public function whereBelongsTo($related, $relationshipName = null, $boolean = 'AND')
    {

        if (!$relationshipName)
        {
            if ($related instanceof Collection)
                $relationshipName = get_class($related->first());
            else
                $relationshipName = strtolower(get_class($related));
        }

        $class = new $this->_parent;
        $class->setQuery($this);
        $class->getQuery()->varsOnly = true;
        $res = $class->$relationshipName();
        $class->getQuery()->varsOnly = false;

        $foreign = $res->_relationVars['foreign'];

        if ($related instanceof Collection)
            $values = $related->pluck($foreign)->toArray();
        else
            $values = array($related->$foreign);


        if (strtolower($boolean)=='and')
            $this->whereIn($res->_relationVars['primary'], $values);
        else
            $this->orWhereIn($res->_relationVars['primary'], $values);

        return $this;
    }

    /**
     * Add an "BelongsTo" relationship with an "or where" clause to the query.
     * Check Laravel Documentation
     * 
     * @return QueryBuilder
     */
    public function orWhereBelongsTo($related, $relationshipName = null)
    {
        return $this->whereBelongsTo($related, $relationshipName, 'OR');
    }


    /**
     * Add subselect queries to count the relations.
     *
     * @param  mixed  $relations
     * @return $this
     */
    public function withCount($relations)
    {
        return $this->withAggregate(is_array($relations) ? $relations : func_get_args(), '*', 'count');
    }

    /**
     * Add subselect queries to include the max of the relation's column.
     *
     * @param  string|array  $relation
     * @param  string  $column
     * @return $this
     */
    public function withMax($relation, $column)
    {
        return $this->withAggregate($relation, $column, 'max');
    }

    /**
     * Add subselect queries to include the min of the relation's column.
     *
     * @param  string|array  $relation
     * @param  string  $column
     * @return $this
     */
    public function withMin($relation, $column)
    {
        return $this->withAggregate($relation, $column, 'min');
    }

    /**
     * Add subselect queries to include the sum of the relation's column.
     *
     * @param  string|array  $relation
     * @param  string  $column
     * @return $this
     */
    public function withSum($relation, $column)
    {
        return $this->withAggregate($relation, $column, 'sum');
    }

    /**
     * Add subselect queries to include the average of the relation's column.
     *
     * @param  string|array  $relation
     * @param  string  $column
     * @return $this
     */
    public function withAvg($relation, $column)
    {
        return $this->withAggregate($relation, $column, 'avg');
    }

    /**
     * Add subselect queries to include the existence of related models.
     *
     * @param  string|array  $relation
     * @return $this
     */
    public function withExists($relation)
    {
        return $this->withAggregate($relation, '*', 'exists');
    }

    public function withAggregate($relations, $column, $function = 'count')
    {

        if (count($relations)==0) {
            return $this;
        }

        $relations = is_array($relations) ? $relations : array($relations);

        foreach ($relations as $key => $values)
        {
            $relation = null;
            $constraints = null;
            $alias = null;

            if (is_string($values) && strpos($values, '@')===false)
            {
                list($relation, $alias) =  explode(' as ', strtolower($values));
                $constraints = null;
            }
            elseif (is_null($values))
            {
                list($relation, $alias) =  explode(' as ', strtolower($key));
                $constraints = null;
            }
            else //if (is_object($values))
            {
                //$values->_where = str_replace("`".$values->_table."`.", "`_child_table_`.", $values->_where);
                list($relation, $alias) =  explode(' as ', strtolower($key));
                $constraints = $values;
            }


            $newparent = new $this->_parent;
            $newparent->getQuery()->varsOnly = true;
            //$newparent->setQuery($this);
            $data = $newparent->$relation();

            //dump($data);

            $column_name = $alias? $alias : $relation.'_'.$function;

            if ($function!='count' && $function!='exists')
                $column_name .= '_'.$column;

            $select = "(SELECT $function($column)";

            if ($function=='exists')
                $select = "EXISTS (SELECT $column";

            $subquery = "$select FROM `$data->_table`";

            if ($data->_relationVars['relationship']=='belongsToMany' 
            || $data->_relationVars['relationship']=='hasManyThrough'
            || $data->_relationVars['relationship']=='hasOneThrough')
            {
                $subquery .= ' ' . $data->_join . ' WHERE `'. $data->_relationVars['classthrough'] . '`.`' . 
                    $data->_relationVars['foreignthrough'] . '` = `' .
                    $this->_table . '`.`' . $data->_relationVars['primary'] . '`';

            }
            else
            {
                $subquery .= " WHERE `$this->_table`.`" . $data->_relationVars['primary'] . "` 
                = `$data->_table`.`" . $data->_relationVars['foreign'] . "`";
            }

            // Revisar este WHERE
            // Es el where de la relacion
            if ($data->_where)
                $subquery .= ' AND ' . str_replace('WHERE ', '', $data->_where);

            // Constraints (if declared)
            if ($constraints)
            {
                list($class, $method, $params) = getCallbackFromString($constraints);
                call_user_func_array(array($class, $method), array_merge(array(&$data), $params));

                $new_where = str_replace("`_child_table_`.", "`".$data->_table."`.", $data->_where);
                $subquery .= str_replace('WHERE',' AND', $new_where);
            }

            $subquery .= ") AS `" . $column_name . "`";

            $this->addSelect($subquery);
            //dump($this->toSql());

        }    

        return $this;

    }

    /**
    * Load a set of aggregations over relationship's column onto the collection.
    *
    * @return Collection
    */
    public function loadAggregate($relations, $column, $function = 'count')
    {
        if (count($relations)==0) {
            return $this;
        }

        $relations = is_array($relations) ? $relations : array($relations);

        foreach($relations as $relation)
        {
            $newparent = new $this->_parent;
            $newparent->getQuery()->varsOnly = true;
            $data = $newparent->$relation();

            $column_name = $relation.'_'.$function;

            if ($function!='count' && $function!='exists')
                $column_name .= '_'.$column;

            $select = "(SELECT $function($column)";

            if ($function=='exists')
                $select = "EXISTS (SELECT $column";

            $subquery = "$select FROM `$data->_table`";

            if ($data->_relationVars['relationship']=='belongsToMany' 
            || $data->_relationVars['relationship']=='hasManyThrough'
            || $data->_relationVars['relationship']=='hasOneThrough')
            {
                $subquery .= ' ' . $data->_join . ' WHERE `'. $data->_relationVars['classthrough'] . '`.`' . 
                    $data->_relationVars['foreignthrough'] . '` = `' .
                    $this->_table . '`.`' . $data->_relationVars['primary'] . '`';

            }
            else
            {
                $subquery .= " WHERE `$this->_table`.`" . $data->_relationVars['primary'] . "` 
                = `$data->_table`.`" . $data->_relationVars['foreign'] . "`";
            }

            $subquery .= ") AS `" . $column_name . "`";

            $p_key = is_array($this->_primary)? $this->_primary[0] : $this->_primary;
            $this->select($p_key)->addSelect($subquery);
            $this->whereIn($p_key, $this->_collection->pluck($this->_primary[0])->toArray());

            $temp = new Collection('stdClass');
            $temp = $this->_connector->execSQL($this->toSql(), $this->_wherevals, $temp);

            foreach ($temp as $t)
            {
                $this->_collection->where($p_key, $t->{$p_key})
                    ->first()->$column_name = $t->$column_name;
            }

        }

        return $this;
    }


    /**
     * Retrieve the "count" result of the query.
     *
     * @param  string  $columns
     * @return int
     */
    public function count($columns = '*')
    {
        return (int) $this->aggregate('count', $columns);
    }

    /**
     * Retrieve the minimum value of a given column.
     *
     * @param  string  $column
     * @return mixed
     */
    public function min($column)
    {
        return $this->aggregate('min', $column);
    }

    /**
     * Retrieve the maximum value of a given column.
     *
     * @param  string  $column
     * @return mixed
     */
    public function max($column)
    {
        return $this->aggregate('max', $column);
    }

    /**
     * Retrieve the sum of the values of a given column.
     *
     * @param  string  $column
     * @return mixed
     */
    public function sum($column)
    {
        return $this->aggregate('sum', $column);

        //return $result ?: 0;
    }

    /**
     * Retrieve the average of the values of a given column.
     *
     * @param  string  $column
     * @return mixed
     */
    public function avg($column)
    {
        return $this->aggregate('avg', $column);
    }

    /**
     * Alias for the "avg" method.
     *
     * @param  string  $column
     * @return mixed
     */
    public function average($column)
    {
        return $this->avg($column);
    }

    /**
     * Execute an aggregate function on the database.
     *
     * @param  string  $function
     * @param  array  $columns
     * @return mixed
     */
    public function aggregate($function, $columns='*')
    {
        $this->_method = "SELECT $function($columns) as aggregate FROM";
        $sql = $this->buildQuery();

        return $this->_connector->query($sql)->fetch_object()->aggregate;
    }



    /**
     * Sets the Query's factory
     * 
     * @return Factory
     */
    public function factory()
    {
        $class = $this->_parent;
        $factory = call_user_func_array(array($class, 'newFactory'), array());
        //$factory = $class::newFactory();

        if (!$factory)
        {
            if (env('APP_DEBUG')==1) throw new Exception('Error looking for '.$class);
            else return null;
        }

        return $factory;

    }


    public function seed($data, $persist)
    {

        $this->_fillableOff = true;

        $col = new Collection($this->_parent);

        foreach ($data as $item)
        {
            if ($persist)
            {
                $col[] = $this->insert($item);
            }
            else
            {
                $col[] = $this->insertUnique($item);
            }
        }

        $this->_fillableOff = false;

        return $col;

    }
    
    public function attach($roles)
    {
        if (is_array($roles))
        {
            foreach ($roles as $role)
                $this->attach($role);
        }
        else
        {
            $record = array(
                $this->_relationVars['foreignthrough'] => $this->_relationVars['current'],
                $this->_relationVars['primarythrough'] => $roles
            );

            DB::table($this->_relationVars['classthrough'])
                ->insertOrIgnore($record);

        }
    }


    public function dettach($roles)
    {
        if (is_array($roles))
        {
            foreach ($roles as $role)
                $this->dettach($role);
        }
        else
        {
            DB::table($this->_relationVars['classthrough'])
                ->where($this->_relationVars['foreignthrough'], $this->_relationVars['current'])
                    ->where($this->_relationVars['primarythrough'], $roles)
                        ->delete();
        }
    }

    public function sync($roles, $remove = true)
    {
        //dd($this->_relationVars); dd($roles);

        if ($remove)
            DB::table($this->_relationVars['classthrough'])
                ->where($this->_relationVars['foreignthrough'], $this->_relationVars['current'])
                    ->delete();

        if (is_array($roles))
        {
            foreach ($roles as $role)
                $this->sync($role, false);
        }
        else
        {
            $record = array(
                $this->_relationVars['foreignthrough'] => $this->_relationVars['current'],
                $this->_relationVars['primarythrough'] => $roles
            );

            DB::table($this->_relationVars['classthrough'])
                ->insertOrIgnore($record);
        }
    }


    public function callScope($scope, $args)
    {
        //echo "<br>SCOPE: ".$this->_parent."::scope".ucfirst($scope)."<br>";
        $func = 'scope'.ucfirst($scope);
        $res = new $this->_parent;
        return call_user_func_array(array($res, $func), array_merge(array($this), $args));
    }

}
