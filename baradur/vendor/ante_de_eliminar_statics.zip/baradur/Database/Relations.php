<?php

Class Relations
{

    private static function recusiveSearch($arraydata, $value, $parent, $matches)
    {
        #echo "RECURSIVE SEARCH: ".$value."::".$parent."<br>";
        foreach ($arraydata as $current)
        {
            //echo "Processing:"; var_dump($current);echo "<br>";
            if (!$parent) // || strpos($parent, '.')==false)
            {
                if (isset($current->$value))
                {
                    if (!in_array($current->$value, $matches))
                        array_push($matches, $current->$value);
                }
            }
            else 
            {
                if (strpos($parent, '.')>0)
                {
                    $temp = explode('.', $parent);
                    $child = array_shift($temp);
                    $newparent = str_replace($child.'.', '', $parent);
                }
                else
                {
                    $child = $parent;
                    $newparent = null;
                }
                $matches = self::recusiveSearch($current->$child, $value, $newparent, $matches);
            }
        }
        return $matches;
    }

    public static function processMorphRelationship($class, $method, $type, $parent)
    {
        //echo "<br>Morph relationship:".$class."::".$method."::".$type."<br>";
        /* $c = new $class; 
        $res = $c->$method(); */

        /* if (count($res)==0)
        { */
            $res = array();
            $res[] = $method.'_id';
            $res[] = $method.'_type';
        /* }
        elseif (count($res)==1)
        {
            $res[] = $method.'_type';
        } */

        //dump($res);
        $primary = is_array($parent->_primary)? $parent->_primary[0] : $parent->_primary;

        $wherein = $parent->_collection->pluck($primary)->toArray();
        $newmodel = Model::instance($class)->whereIn($res[0], $wherein); //call_user_func_array(array($c, 'whereIn'), array($res[0], implode(',', $wherein)));
        $result = $newmodel->where($res[1], $parent->_parent);

        if ($type == 'morphOne') $result->limit(1);

        $result->_relationVars = array(
            'foreign' => $res[0],
            'primary' => is_array($primary)? $primary[0] : $primary,
            'relationship' => $type,
            'relation_type' => $method.'_type',
            'current_type' => $parent->_parent,
            'current_id' => $parent->_collection->first()->$primary);

        return $result;

    }

    public static function processMorphRelationshipThrough($class, $method, $relation, $parent)
    {
        //echo "<br>Morph relationship through:".$class."::".$method."<br>";

        $mainclass = Model::instance($class);
        //$secondaryclass = Model::instance($class);

        $res = array();
        $res['id'] = $relation=='morphToMany'? Helpers::camelCaseToSnakeCase($class, false).'_id' : $mainclass->_primary[0];
        $res['related'] = $method.'_id';
        $res['type'] = $method.'_type';

        //dump($res);

        $primary = $parent->_primary[0];

        $wherein = $parent->_collection->pluck($primary)->toArray();

        $primarytable = $mainclass->_table;
        $secondary = Helpers::getPlural($method);

        $result = DB::table($primarytable)
            ->join($secondary, $relation=='morphToMany'? $res['id'] : $res['related'], '=', $mainclass->_primary[0])
            ->whereIn($relation=='morphToMany'? $res['related'] : $res['id'], $wherein)
            ->where($secondary.'.'.$res['type'], $relation=='morphToMany'?$parent->_parent : $class);

        $result->_relationVars = array(
            'foreign' => $res['id'],
            'primary' => $relation=='morphToMany'? $primary : 'tag_id',
            'foreignthrough' => $res['related'],
            'relationship' => $relation,
            'relation_type' => $method.'_type',
            'classthrough' => $secondary,
            'current_type' => $parent->_parent,
            'current_id' => $parent->_collection->first()->$primary
        );

        //dump($result->_relationVars);

        return $result;

    }

    public static function processMorphRelationshipTo($parent)
    {
        //echo "<br>Morph relationship To<br>";

        $primary = is_array($parent->_primary)? $parent->_primary[0] : $parent->_primary;

        $keys = array_keys($parent->_collection->first()->toArray());

        $type = null;
        $id = null;
        foreach ($keys as $key)
        {
            if (substr($key, -3)=='_id') $id = $key;
            if (substr($key, -5)=='_type') $type = $key;
        }

        if (!$type || !$id)
            return null;

        $classname = $parent->_collection->pluck($type)->first();
        $wherein = $parent->_collection->pluck($id)->toArray();

        $class = Model::instance($classname);
        $result = $class->whereIn($class->_primary[0], $wherein);

        $result->_relationVars = array(
            'foreign' => $class->_primary[0],
            'primary' => $id,
            'relationship' => 'morphTo');

        //dump($result->_relationVars);

        return $result;

    }

    public static function processRelationship($class, $foreign, $primary, $relationship, $parent)
    {
        //echo "<br>Processing relationship:".$class."<br>";
        //var_dump($this);
        //dump(func_get_args());

        $columns = '*'; // $parent->_relationColumns;

        //dd($columns);

        $res = null;

        if (class_exists($class))
        {
            $res = Model::instance($class)->select(array($columns)); //call_user_func_array(array($class, 'select'), array($columns));
        }
        else
        {
            $res = DB::table(Helpers::camelCaseToSnakeCase($class, false))->select($columns);
            $res->setConnector($parent->_connector);
        }
        
        if ($relationship=='belongsTo')
        {
            if (!$foreign) $foreign = 'id';
            if (!$primary) $primary = Helpers::camelCaseToSnakeCase($res->_parent, false).'_id';
        }
        else if ($relationship=='hasOne' || $relationship=='hasMany')
        {
            if (!$foreign) $foreign = ($parent->_original? $parent->_original :
                                        Helpers::camelCaseToSnakeCase($parent->_parent, false)).'_id';
            if (!$primary) $primary = is_array($parent->_primary)? $parent->_primary[0] : $parent->_primary;
        }

        //echo $class.":".$foreign.":".$primary.":".$relationship."<br>";

        $res->_relationVars = array(
            'foreign' => $foreign,
            'primary' => $primary,
            'relationship' => $relationship,
            'relation_class' => $parent->_parent,
            'relation_current' => $parent->varsOnly? null : $parent->_collection->first()->$primary
        );

        if ($parent->varsOnly)
            return $res;

        
        $wherein = array();

        $wherein = $parent->_collection->pluck($primary)->toArray(); //self::recusiveSearch($parent->_collection, $primary, null, $wherein);
        $res = $res->whereIn($res->_table.'.'.$foreign, $wherein);
        
        //dump($parent);
        if ($parent->_extraQuery)
        {
            //dump($parent->_extraQuery);
            list($class, $method, $params) = getCallbackFromString($parent->_extraQuery);
            array_shift($params);
            call_user_func_array(array($class, $method), array_merge(array($res), $params));
            //dump($res);
            
            //$new_where = str_replace("`_child_table_`.", "`".$res->_table."`.", $res->_where);
            //$res = $res->whereRaw(str_replace('WHERE','', $new_where));
        }
        //dump($res);

        /* if ($parent->_nextRelation && isset($parent->_nextRelation['constraints']))
        {
            //echo "PROCESSING CHILD RELATION";dump($parent->_nextRelation);
            $res->whereHas($parent->_nextRelation['relation'], $parent->_nextRelation['constraints']);
        } */

        

        if ($parent->_nextRelation)
        {
            foreach ($parent->_nextRelation as $k => $v) 
            {
                if ($k!='_constraints')
                    $res->_eagerLoad[$k] = $v;
            }

        }

        /* if(count($parent->_eagerLoad)==0)
        {
            if ($relationship=='hasOne' || $relationship=='belongsTo' || $relationship=='morphOne')
                return $res->get()->first();
            else
                return $res->get();
        } */

        return $res;

    }


    public static function processRelationshipThrough($class, $classthrough, $foreignthrough, 
        $foreign, $primary, $primarythrough, $relationship, $parent)
    {
        //echo "RELATIONSHIP THROUGH : ".$parent->_relationName.":".$relationship."<br>";
        //dump(func_get_args());
        //var_dump($this);
        //dd($parent);

        $columns = '*'; //$parent->_relationColumns;

        $secondarytable = Helpers::camelCaseToSnakeCase($classthrough, false);
        if (class_exists($classthrough))
            $secondarytable = call_user_func(array($classthrough, 'getTable'), array());

        $res = null;
        if (class_exists($class))
            $res = Model::instance($class)->select($columns); //call_user_func_array(array($class, 'select'), array($columns));
        else
        {
            $res = DB::table(Helpers::camelCaseToSnakeCase($class, false))->select($columns);
            $res->setConnector($parent->_connector);
        }


        $res = $res->join($secondarytable, $primarythrough, '=', $foreign);

        $res->_relationVars = array(
            'classthrough' => $classthrough,
            'foreignthrough' => $foreignthrough,
            'primarythrough' => $primarythrough,
            'foreign' => $foreign,
            'primary' => $primary,
            'relationship' => $relationship
        );
        

        if ($parent->varsOnly==1)
            return $res;

        $wherein = array();
        $wherein = $parent->_collection->pluck($primary)->toArray(); //self::recusiveSearch($parent->_collection, $primary, null, $wherein);

        if ($relationship=='belongsToMany')
        {
            $res->_relationVars['current'] = /* count($wherein)>0?  */$wherein[0] /* : $current */;
        }


        /* if ($relationship=='belongsToMany')
            $res = $res->whereIn($classthrough.'.'.$foreignthrough, $wherein);
        else
            $res = $res->whereIn($res->_table.'.'.$foreign, $wherein); */

        $res = $res->whereIn($foreignthrough, $wherein);
        
        if ($parent->_extraQuery)
        {
            list($class, $method, $params) = getCallbackFromString($parent->_extraQuery);
            array_shift($params);
            call_user_func_array(array($class, $method), array_merge(array($res), $params));

            //$new_where = str_replace("`_child_table_`.", "`".$res->_table."`.", $res->where);
            //if ($new_where) $res = $res->whereRaw(str_replace('WHERE','', $new_where));
        }

        /* if ($parent->_nextRelation && isset($parent->_nextRelation['constraints']))
        {
            //echo "PROCESSING CHILD RELATION";dump($parent->_nextRelation);
            $res->whereHas($parent->_nextRelation['relation'], $parent->_nextRelation['constraints']);
        } */

        if ($parent->_nextRelation)
        {
            foreach ($parent->_nextRelation as $k => $v) 
            {
                if ($k!='_constraints')
                    $res->_eagerLoad[$k] = $v;
            }

        }
        
        /* if(count($parent->_eagerLoad)==0)
        {
            if ($relationship=='hasOne' || $relationship=='belongsTo' || $relationship=='morphOne')
                return $res->get()->first();
            else
                return $res->get();
        } */

        return $res;

    }

    public static function insertRelation($parent, $res, $relation)
    {
        $classthrough = $res->_relationVars['classthrough'];
        $relationship = $res->_relationVars['relationship'];
        $foreignthrough = $res->_relationVars['foreignthrough'];
        $primarythrough = $res->_relationVars['primarythrough'];
        $foreign = $res->_relationVars['foreign'];
        $primary = $res->_relationVars['primary'];
        $oneOfMany = $res->_relationVars['oneOfMany'];

        //dump($res->_relationVars);

        if ($relationship=='mothToMany')
            $foreignthrough = $res->_relationVars['foreignthrough'];


        if (isset($parent->_eagerLoad[$relation]['_constraints'])
            && !isset($res->_eagerLoad))
        {
            $res->_eagerLoad = $parent->_eagerLoad[$relation]['_constraints']->_eagerLoad;
        }

        if (isset($parent->_hasConstraints))
        {
            //dump($parent->_hasConstraints);
            $r = $parent->_hasConstraints['relation'];
            $r = str_replace($parent->_relationName.'.', '', $r);
            $c = $parent->_hasConstraints['constraints'];
            $res->_has($r, $c);
        }

        $key = in_array($relationship, array('belongsToMany', 'hasManyThrough', 'morphToMany')) ?
            $foreignthrough : ($relationship=='morphedByMany'? $primary : $foreign);

        //dump($key);
        //dump($res);
        if ($res->_method == 'SELECT * FROM')
        {
            $res->_method = "SELECT `$res->_table`.*";
        
            if (in_array($relationship, array('belongsToMany', 'hasManyThrough', 'morphToMany', 'morphedByMany')))
            {
                $res->_method .= ", `$classthrough`.`".$key."` as bardur_through_key";
                $key = 'bardur_through_key';
            }

            $res->_method .= " FROM";
        }

        $res = $res->get();
        //dump($res); //dump($parent);

        $columns = $parent->_relationColumns;
        $relation = $parent->_relationName;

        if ($relationship=='morphedByMany')
            $primary = $parent->_primary[0];

        //dump("KEY: $key");

        foreach ($parent->_collection as $current)
        {
            /* if ($relationship=='belongsToMany' || $relationship=='hasManyThrough')
            {
                $item = $columns!='*' ? 
                    $res->where($foreignthrough, $current->$primary)->keys($columns) :
                    $res->where($foreignthrough, $current->$primary);
            }

            elseif ($relationship=='hasMany' || $relationship=='morphMany')
            {
                $item = $columns!='*' ? 
                    $res->where($foreign, $current->$primary)->keys($columns) :
                    $res->where($foreign, $current->$primary);
            } */

            if ($oneOfMany)
            {
                $item = $columns!='*' ? 
                    $res->where($key, $current->$primary)->first()->keys($columns) :
                    $res->where($key, $current->$primary)->first();

            }
            elseif (in_array($relationship, array('hasOne', 'belongsTo', 'morphOne', 'morphTo')))
            {
                $item = $columns!='*' ? 
                    $res->where($key, $current->$primary)->first()->keys($columns) :
                    $res->where($key, $current->$primary)->first();
            }
            else
            {
                $item = $columns!='*' ? 
                    $res->where($key, $current->$primary)->keys($columns) :
                    $res->where($key, $current->$primary);
            }

            $current->$relation = $item;
            
        }

        $parent->_loadedRelations[] = $relation;

        //dump($parent->_collection);
    }


}