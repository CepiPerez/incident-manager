<?php

class QueryException extends RuntimeException
{

}
