<?php

class SoftDeletes
{
    # Dummy class

}