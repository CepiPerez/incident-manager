<?php

Class Migration
{
    
    public function __construct()
    {
        //$this->table = new stdClass;        
    }

}

