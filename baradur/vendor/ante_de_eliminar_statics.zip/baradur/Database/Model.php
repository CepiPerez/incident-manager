<?php

/**
 * 
 * @method static Collection all()
 * @method static $this first()
 * @method static Collection paginate(int $value)
 * @method static $this find(string $value)
 * @method static $this findOrFail(string $value)
 * @method static Model firstOrNew()
 * @method static Model firstOrCreate()
 * @method static QueryBuilder select(string|array $column)
 * @method static QueryBuilder selectRaw(string $select)
 * @method static QueryBuilder where(string $column, string $param1, string $param2)
 * @method static QueryBuilder whereIn(string $colum, array $values)
 * @method static QueryBuilder whereNotIn(string $colum, array $values)
 * @method static QueryBuilder whereColumn(string $first, string $operator, string $second, string $chain)
 * @method static QueryBuilder whereRelation(string $relation, string $column, string $comparator, string $value)
 * @method static QueryBuilder whereBelongsTo(string $related, string $relationshipName=null, $boolean='AND')
 * @method static QueryBuilder with(string|array $relations)
 * @method static QueryBuilder withCount(string|array $relations)
 * @method static QueryBuilder withMax(string $relations, string $column)
 * @method static QueryBuilder withMin(string $relations, string $column)
 * @method static QueryBuilder withAvg(string $relations, string $column)
 * @method static QueryBuilder withSum(string $relations, string $column)
 * @method static QueryBuilder withExists(string|array $relations)
 * @method static QueryBuilder withTrashed()
 * @method static QueryBuilder skip(int $value)
 * @method static QueryBuilder take(int $value)
 * @method static QueryBuilder latest($colun)
 * @method static QueryBuilder oldest($column)
 * @method static QueryBuilder orderBy(string $column, string $order)
 * @method static QueryBuilder orderByRaw(string $order)
 * @method static int count(string $column)
 * @method static mixed min(string $column)
 * @method static mixed max(string $column)
 * @method static mixed avg(string $column)
 * @method static mixed average(string $column)
 * @method static $this create(array $record)
 * @method static QueryBuilder has(string $relation, string $comparator=null, string $value=null)
 * @method static QueryBuilder whereHas(string $relation, Query $filter=null, string $comparator=null, string $value=null)
 * @method static QueryBuilder withWhereHas(string $relation, Query $filter=null)
 *
 */

class Model
{
    protected static $_parent = 'myparent';
    protected static $_table;
    protected static $_primaryKey = 'id';
    protected static $_fillable = array();
    protected static $_guarded = null;
    protected static $_hidden = array();
    protected static $_factory;
    protected static $_connector;
    protected static $_query;
    protected static $_softDelete = false;

    protected $_original = array();
    protected $_relations = array();
    
    protected $useSoftDeletes = false;

    /**
     * Sets database table used in model\
     * Default value is Model' name in lowercase and plural
     */
    protected $table = null;

    /**
     * Sets table primary key\
     * Default value is 'id'
     */
    protected $primaryKey = null;

    /**
     * Sets fillable columns\
     * Default is empty array
     */
    protected $fillable = array();

    /**
     * Sets guarded columns\
     * Default is null
     */
    protected $guarded = null;

    /**
     * Sets hidden attributes\relationships
     */
    protected $hidden = array();

    /**
     * Sets the Model's factory
     */
    protected $factory = null;


    protected $wasRecentlyCreated = false;

    /**
     * Sets the connector for database\
     * Uses main connector by default, wich is
     * created using .env variables\
     * Example:\
     * array('host' => '192.168.1.1', 'user' => 'admin', 'password' => 'admin',
     * 'database' => 'mydatabase', 'port' => 3306);
     * @var array
     */
    Protected $connector = null;


    
    public function __construct($empty = false)
    {

        if (!$empty)
        {
            if (isset($this->connector))
            {
                $conn = new Connector($this->connector['host'], $this->connector['user'], 
                    $this->connector['password'], $this->connector['database'], 
                    $this->connector['port']?$this->connector['port']:3306);
    
                self::$_connector = $conn;
            }
            else
            {
                global $database;
                self::$_connector = $database;
            }
        }

        if (isset($this->table))
        {
            self::$_table = $this->table;
        }
        else if (!isset(self::$_table))
        {
            self::$_table = self::$_parent;
            self::$_table = Helpers::camelCaseToSnakeCase(self::$_table);
        }

        if ($this->primaryKey)
        {
            self::$_primaryKey = $this->primaryKey; 
        }
        else
        {
            self::$_primaryKey = 'id';
        }

        if ($this->factory)
        {
            self::$_factory = $this->factory; 
        }
        else
        {
            self::$_factory = self::$_parent.'Factory';
        }

        #if ($this->fillable)
        #{
            self::$_fillable = $this->fillable; 
        #}

        #if ($this->guarded)
        #{
            self::$_guarded = $this->guarded; 
        #}

        #if ($this->hidden)
        #{
            self::$_hidden = $this->hidden; 
        #}

        if ($this->useSoftDeletes)
        {
            self::$_softDelete = $this->useSoftDeletes;
        }
        else
        {
            unset($this->useSoftDeletes);
            //unset($this->_original);
            unset($this->_trashed);
        }
        
  
        unset($this->connector);
        unset($this->table);
        unset($this->primaryKey);
        unset($this->fillable);
        unset($this->guarded);
        unset($this->factory);
        unset($this->hidden);

        $routeKey = $this->getRouteKeyName();

        if ($empty)
            self::$_query = null;
        else
            self::$_query = new QueryBuilder(self::$_connector, self::$_table, self::$_primaryKey, 
                        self::$_parent, self::$_fillable, self::$_guarded, self::$_hidden, $routeKey, self::$_softDelete);

        
    }

    public function getRouteKeyName()
    {
        return self::$_primaryKey;
    }

    public function getPrimaryKey()
    {
        return $this->primaryKey;
    }


    public static function instance($parent, $table=null)
    {
        //echo "instance() for $parent<br>";
        self::$_parent = $parent;
        self::$_softDelete = 0;
        return self::getInstance($table)->getQuery();
    }

    /**
     * @return $this
     */
    public static function getInstance($table=null)
    {
        if (isset($table))
        {
            if (strpos($table, ':')>0)
            {
                list($table, $primary) = explode(':', $table);
                self::$_primaryKey = $primary;
            }

            self::$_table = $table;
        }
        else
        {
            self::$_table = Helpers::camelCaseToSnakeCase(self::$_parent);
        }
        //echo "getInstance for ".self::$_parent." :: table ".self::$_table."<br>";
        if (self::$_parent=='myparent')
            self::$_parent = 'DB';

        return new self::$_parent;
    }

    /**
     * @return QueryBuilder
     */
    public function getQuery()
    {
        if (!isset(self::$_query) || self::$_query->_parent!=get_class($this))
        {
            self::$_query = self::instance(get_class($this));
            self::$_query->_collection->append($this);
        }
            
        return self::$_query;
    }

    public function setQuery($query, $full=true)
    {
        if (!$full)
        {
            unset($query->_parent);
            unset($query->_table);
            unset($query->_primary);
            unset($query->_foreign);
            unset($query->_fillable);
            unset($query->_guarded);
        }

        self::$_query = $query;
        #foreach($query as $key => $val)
        #    self::$_query->$key = $val;
    }

    public function getTable()
    {
        return self::$_table;
    }

    public function _setOriginalKey($key, $val)
    {
        $this->_original[$key] = $val;
    }

    public function _getOriginalKeys()
    {
        return $this->_original;
    }

    public function _setOriginalRelations($relations)
    {
        $this->_relations = $relations;
    }

    public function _setRecentlyCreated($val)
    {
        $this->wasRecentlyCreated = $val;
    }


    protected $_trashed = null;

    public function _setTrashed($val)
    {
        if (!self::$_softDelete)
            throw new Exception('Tryin to use softDelete method on a non-softDelete Model');

        $this->_trashed = $val;
    }

    public function trashed()
    {
        if (!self::$_softDelete)
            throw new Exception('Tryin to use softDelete method on a non-softDelete Model');

        return isset($this->_trashed);
    }

    
    /**
     * Soft-deletes the current model from database
     * 
     * @return bool
     */
    public function softDeletes()
    {
        if (!self::$_softDelete)
            throw new Exception('Tryin to use softDelete method on a non-softDelete Model');

        if( isset($this) && $this instanceof self )
        {
            if (count($this->_original)==0)
                throw new Exception('Error! Trying to delete new Model');

            return $this->getQuery()->softDeletes($this->_original);
        }
    }

    /**
     * Restore the trashed model
     * 
     * @return bool
     */
    public function restore()
    {
        if (!self::$_softDelete)
            throw new Exception('Tryin to use softDelete method on a non-softDelete Model');

        if( isset($this) && $this instanceof self )
        {
            if (count($this->_original)==0)
                throw new Exception('Error! Trying to delete new Model');

            return $this->getQuery()->restore($this->_original);
        }
    }

    /**
     * Permanently deletes the trashed model
     * 
     * @return bool
     */
    public function forceDelete()
    {
        if (!self::$_softDelete)
            throw new Exception('Tryin to use softDelete method on a non-softDelete Model');

        if( isset($this) && $this instanceof self )
        {
            if (count($this->_original)==0)
                throw new Exception('Error! Trying to delete new Model');

            return $this->getQuery()->forceDelete($this->_original);
        }
    }

   
    public function __get($name)
    {
        //dump("GET::$name");
        if ($name=='exists')
            return count($this->_original)>0;

        if ($name=='wasRecentlyCreated')
            return $this->wasRecentlyCreated;
        
        if (method_exists($this, 'get'.ucfirst($name).'Attribute'))
        {
            $fn = 'get'.ucfirst($name).'Attribute';
            return $this->$fn();
        }

        if (method_exists($this, $name.'Attribute'))
        {
            $fn = $name.'Attribute';
            $nval = $this->$fn($name, (array)$this);
            return $nval['get'];
        }

        if (method_exists($this, $name))
        {
            /* if (count($this->getQuery()->_collection)==0)
            {
                $array = new Collection($this->_parent);
                $array->put($this);
                
                $this->getQuery()->_collection = $array;
            } */
            global $preventLazyLoading;

            if ($preventLazyLoading)
                throw new Exception("Attempted to lazy load [$name] on Model [".self::$_parent."]");

            /* dump($this); */
            $this->load($name);
            //$instance = self::instance(get_class($this));
            //$instance->_collection->append($this);
            //$res = $instance->load($name)->first();


            //dd($res);

            /* if (get_class($this)=='User')
            {
                //$this->$name = $res;
                $_SESSION['user'] = $this;
            } */
            
            return $this->$name;

        }
        else
        {
            //die($name);
            global $preventAccessingMissingAttributes;
            if ($preventAccessingMissingAttributes)
                throw new Exception("The attribute [$name] either does not 
                    exist or was not retrieved for model [".get_class($this)."]", 120);
        }


    }

    # PHP > 5.3 only
    /* public static function __callStatic($name, $arguments)
    {
        if (method_exists(get_called_class(), 'scope'.ucfirst($name)))
        {
            return self::getInstance()->getQuery()->callScope($name, $arguments);
        }

        #else if (method_exists('QueryBuilder', $name))
        #{
        #    return self::getInstance()->getQuery()->$name($arguments);
        #}
    } */


    /**
     * Returns model as array
     * 
     * @return array
     */
    public function toArray()
    {
        $c = new Collection(self::$_parent, self::$_hidden);
        return $c->toArray($this);
    }


    public static function newFactory()
    {
        //echo "Called factory(): ".self::$_factory;
        $class = self::$_factory;
        return new $class;
    }


     /**
     * Declare model observer
     * 
     */
    public static function observe($class)
    {
        global $version, $observers;
        $model = /* $version=='NEW'? get_called_class() : */ self::$_parent;
        if (!isset($observers[$model]))
            $observers[$model] = $class;
    }

    private function checkObserver($function, $model)
    {
        global $observers;
        $class = get_class($this);
        if (isset($observers[$class]))
        {
            $observer = new $observers[$class];
            if (method_exists($observer, $function))
                $observer->$function($model);
        }
    }

    /**
     * Get the original Model attribute(s)
     * 
     * @param string $value
     * @return mixed
     */
    public function getOriginal($value=null)
    {
        if ($value)
            return $this->_original[$value];

        return $this->_original;

    }

    /**
     * Determine if attribute(s) has changed
     * 
     * @param string $value
     * @return mixed
     */
    public function isDirty($value=null)
    {
        if ($value)
            return $this->_original[$value] != $this->$value;

        foreach ($this->_original as $key => $val)
        {
            if ($this->$key != $val)
                return true;
        }
        return false;

    }

    /**
     * Determine if attribute(s) has remained unchanged
     * 
     * @param string $value
     * @return mixed
     */
    public function isClean($value=null)
    {
        if ($value)
            return $this->_original[$value] == $this->$value;

        $res = true;
        foreach ($this->_original as $key => $val)
        {
            if ($this->$key != $val)
            {
                $res = false;
                break;
            }
        }
        return $res;

    }

    /**
     * Re-retrieve the model from the database.\
     * The existing model instance will not be affected
     * 
     * @return Model
     */
    public function fresh()
    {
        if (count($this->_original)==0)
            throw new Exception('Trying to re-retrieve from a new Model'); 

        return $this->getQuery()->fresh($this->_original, null);

    }

    /**
     * Re-retrieve the model from the database.\
     * The existing model instance will not be affected
     * 
     * @return Model
     */
    public function refresh()
    {
        if (count($this->_original)==0)
            throw new Exception('Trying to re-retrieve from a new Model'); 

        $res = $this->getQuery()->refresh($this->_original, $this->_relations);

        foreach($this as $key => $val)
            unset($this->$key);

        foreach ($res as $key => $val)
        {
            $this->$key = $val;
        }

    }


    public static function fillableOff()
    {
        self::getInstance()->_fillableOff = true;
    }

    /**
     * Set a factory to seed the model
     * 
     * @return Factory
     */
    public static function factory()
    {
        return self::getInstance()->getQuery()->factory();
    }

    public static function seed($array, $persist)
    {
        return self::getInstance()->getQuery()->seed($array, $persist);
    }


    public static function shouldBeStrict($shouldBeStrict = true)
    {
        self::preventLazyLoading($shouldBeStrict);
        self::preventSilentlyDiscardingAttributes($shouldBeStrict);
        self::preventAccessingMissingAttributes($shouldBeStrict);
    }

    public static function preventLazyLoading($prevent=true)
    {
        global $preventLazyLoading;
        $preventLazyLoading = $prevent;
    }

    public static function preventSilentlyDiscardingAttributes($prevent=true)
    {
        global $preventSilentlyDiscardingAttributes;
        $preventSilentlyDiscardingAttributes = $prevent;
    }

    public static function preventAccessingMissingAttributes($prevent=true)
    {
        global $preventAccessingMissingAttributes;
        $preventAccessingMissingAttributes = $prevent;
    }


    /**
     * Saves the model in database
     * 
     * @return bool
     */
    public function save()
    {
        $res = self::instance(get_class($this));

        //dump($res);

        //dump($this);
        //dd($this->_getOriginalKeys());

        if (count($this->_original)>0)
        {
            $res->_fillableOff = true;
            $final = $res->update($this, $this->_original);
            $res->_fillableOff = false;
        }
        else
        {
            $res->_fillableOff = true;         
            $final = $res->create($this);
            $res->_fillableOff = false;
        }

        return $final;
    }

    /**
     * Save the model and all of its relationships
     * 
     * @return bool
     */
    public function push()
    {
        return $this->getQuery()->push($this, count($this->_original)==0);
    }


    /**
     * Creates a new record in database\
     * Returns new record
     * 
     * @param array $record
     * @return object
     */
    /* public static function create($record)
    {
        return self::getInstance()->getQuery()->create($record);
    } */

    /**
     * Updates a record or an array of reccords in database
     * 
     * @param array $record
     * @return bool
     */
    public function update($record)
    {
        //var_dump(self::getInstance()->getQuery());
        if( isset($this) && $this instanceof self )
        {
            //$this->checkObserver('updating', $this);

            $res = self::instance(get_class($this));
            $primary = $this->getInstance()->getRouteKeyName();
            $res = $res->where($primary, $this->$primary)->update($record);

            //if ($res) $this->checkObserver('updated', $this);

            return $res;
        }

        //return self::getInstance()->getQuery()->update($record);
    }

    /**
     * Deletes the current model from database
     * 
     * @return bool
     */
    public function delete()
    {
        if( isset($this) && $this instanceof self )
        {
            $this->checkObserver('deleting', $this);

            $res = self::instance(get_class($this));
            $primary = $this->getRouteKeyName();
            $res = $res->where($primary, $this->$primary)->delete();

            if ($res) $this->checkObserver('deleted', $this);

            return $res;
        }

        //return self::getInstance()->getQuery()->update($record);
    }




    /**
     * Adds records from a sub-query inside the current records\
     * Check Laravel documentation
     * 
     * @return Model
     */
    public function load($relations)
    {
        if( isset($this) && $this instanceof self )
        {
            $relations = is_string($relations) ? func_get_args() : $relations;
            //dd($relations);
            $res = $this->getQuery();
            //dump($res);
            if(count($res->_collection)==0)
                $res->_collection->append($this);
            
            $res->load($relations);


            /* foreach ($relations as $relation)
            {
                echo "LOADING $relation<br>";
                $instance = self::instance(get_class($this));
                $instance->_collection->append($this);
                $res = $instance->load($relation)->first()->$relation;
            } */
            return $this;
        }
    }



    /**
     * Makes a relationship\
     * Check Laravel documentation
     * 
     * @param string $class - Model class (or table name)
     * @param string $foreign - Foreign key
     * @param string $primary - Primary key
     * @return QueryBuilder
     */
    public function hasMany($class, $foreign=null, $primary=null)
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->hasMany($class, $foreign, $primary);
    }

    /**
     * Makes a relationship\
     * Check Laravel documentation
     * 
     * @param string $class - Model class (or table name)
     * @param string $foreign - Foreign key
     * @param string $primary - Primary key
     * @return QueryBuilder
     */
    public function belongsTo($class, $foreign=null, $primary=null)
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->belongsTo($class, $foreign, $primary, get_class($this));
    }

    /**
     * Makes a relationship\
     * Check Laravel documentation
     * 
     * @param string $class - Model class (or table name)
     * @param string $foreign - Foreign key
     * @param string $primary - Primary key
     * @return QueryBuilder
     */
    public function hasOne($class, $foreign=null, $primary=null)
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->hasOne($class, $foreign, $primary);
    }

    /**
     * Makes a relationship\
     * Check Laravel documentation
     * 
     * @param string $class - Model class (or table name)
     * @param string $classthrough - Model class through (or table name)
     * @param string $foreignthrough - Foreign key from through 
     * @param string $foreign - Foreign key
     * @param string $primary - Primary key
     * @param string $primarythrough - Primary key through
     * @return QueryBuilder
     */
    public function hasManyThrough($class, $classthrough, $foreignthrough, $foreign, $primary='id', $primarythrough='id')
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->hasManyThrough($class, $classthrough, $foreignthrough, $foreign, $primary, $primarythrough);
    }
    
    /**
     * Makes a relationship\
     * Check Laravel documentation
     * 
     * @param string $class - Model class (or table name)
     * @param string $classthrough - Model class through (or table name)
     * @param string $foreignthrough - Foreign key from through 
     * @param string $foreign - Foreign key
     * @param string $primary - Primary key
     * @param string $primarythrough - Primary key through
     * @return QueryBuilder
     */
    public function hasOneThrough($class, $classthrough, $foreignthrough=null, $foreign=null, $primary=null, $primarythrough=null)
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->hasOneThrough($class, $classthrough, $foreignthrough, $foreign, $primary, $primarythrough);
    }

    /**
     * Makes a relationship\
     * Check Laravel documentation
     * 
     * @param string $class - Model class (or table name)
     * @param string $foreign - Foreign key
     * @param string $primary - Primary key
     * @return QueryBuilder
     */
    public function belongsToMany($class, $foreign=null, $primary=null, $foreignthrough=null, $primarythrough=null)
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);
        
        return $res->belongsToMany($class, $foreign, $primary, $foreignthrough, $primarythrough);
    }

    public function morphTo()
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->morphTo();
    }

    public function morphOne($class, $method)
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->morphOne($class, $method);
    }

    public function morphMany($class, $method)
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->morphMany($class, $method);
    }

    public function morphToMany($class, $method)
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->morphToMany($class, $method);
    }

    public function morphedByMany($class, $method)
    {
        $res = $this->getQuery();
        if(count($res->_collection)==0)
            $res->_collection->append($this);

        return $res->morphedByMany($class, $method);
    }


    /**
     * Eager load relation's column aggregations on the model.
     *
     * @param  array|string  $relations
     * @param  string  $column
     * @param  string  $function
     * @return Model
     */
    public function loadAggregate($relations, $column, $function = null)
    {
        $res = $this;
        if( isset($this) && $this instanceof self )
        {
            $relations = is_string($relations) ? func_get_args() : $relations;

            foreach ($relations as $relation)
            {
                $instance = self::instance(get_class($this));
                $instance->_collection->append($this);
                $res = $instance->loadAggregate($relation, $column, $function); //->first();
            }
        }
        return $res;
    }


   

    /**
     * Eager load relation counts on the model.
     *
     * @param  array|string  $relations
     * @return Model
     */
    public function loadCount($relations)
    {
        $relations = is_string($relations) ? func_get_args() : $relations;

        return $this->loadAggregate($relations, '*', 'count');
    }

    /**
     * Eager load relation max column values on the model.
     *
     * @param  array|string  $relations
     * @param  string  $column
     * @return Model
     */
    public function loadMax($relations, $column)
    {
        return $this->loadAggregate($relations, $column, 'max');
    }

    /**
     * Eager load relation min column values on the model.
     *
     * @param  array|string  $relations
     * @param  string  $column
     * @return Model
     */
    public function loadMin($relations, $column)
    {
        return $this->loadAggregate($relations, $column, 'min');
    }

    /**
     * Eager load relation's column summations on the model.
     *
     * @param  array|string  $relations
     * @param  string  $column
     * @return Model
     */
    public function loadSum($relations, $column)
    {
        return $this->loadAggregate($relations, $column, 'sum');
    }

    /**
     * Eager load relation average column values on the model.
     *
     * @param  array|string  $relations
     * @param  string  $column
     * @return Model
     */
    public function loadAvg($relations, $column)
    {
        return $this->loadAggregate($relations, $column, 'avg');
    }

    /**
     * Eager load related model existence values on the model.
     *
     * @param  array|string  $relations
     * @return Model
     */
    public function loadExists($relations)
    {
        $relations = is_string($relations) ? func_get_args() : $relations;
        return $this->loadAggregate($relations, '*', 'exists');
    }





}