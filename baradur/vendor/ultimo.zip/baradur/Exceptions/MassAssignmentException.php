<?php

class MassAssignmentException extends RuntimeException
{
    //
}