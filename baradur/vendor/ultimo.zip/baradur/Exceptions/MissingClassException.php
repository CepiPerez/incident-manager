<?php

class MissingClassException extends RuntimeException
{
    //
}