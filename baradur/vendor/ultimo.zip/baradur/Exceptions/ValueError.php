<?php

class ValueError extends Exception
{

}