<?php

class Middleware
{
    public function handle($request, $next)
    {        
        return $request;
    }

}