<?php

class ItemNotFoundException extends RuntimeException
{

}
