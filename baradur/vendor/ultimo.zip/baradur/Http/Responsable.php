<?php

interface Responsable
{

    public function toResponse($request);

}
