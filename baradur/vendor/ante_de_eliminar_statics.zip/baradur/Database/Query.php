<?php

Class Query extends Model
{

    public static function where($column, $condition='', $value='')
    {
        return parent::getInstance()->getQuery()->where($column, $condition, $value);
    }

    public static function relation($relation)
    {
        return parent::getInstance()->getQuery()->_has($relation);
    }
    
}
